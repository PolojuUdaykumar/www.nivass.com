import type { Config } from 'tailwindcss';
export default { content: ['./src/**/*.{ts,tsx}'], theme: { extend: {
  colors: { accent: { DEFAULT: '#5B4BE0', 50: '#F1EFFE', 300: '#8B7FF0', 700: '#3F31B8' }, st: { new: '#2563eb', accepted: '#0d9488', pending: '#d97706', started: '#7c3aed', done: '#16a34a', rejected: '#ea580c', cancelled: '#e11d48' } },
  borderRadius: { card: '16px', ctl: '10px', dlg: '20px' } } }, plugins: [] } satisfies Config;
