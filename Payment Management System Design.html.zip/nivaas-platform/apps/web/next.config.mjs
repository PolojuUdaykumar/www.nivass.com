export default { transpilePackages: ['@nivaas/shared'], images: { remotePatterns: [{ protocol: 'https', hostname: '**' }] } };
