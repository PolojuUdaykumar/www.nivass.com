'use client';
import { useEffect } from 'react';
import { io } from 'socket.io-client';
import { useQueryClient } from '@tanstack/react-query';
import { token } from './api';
/** Invalidate queries when the server broadcasts booking/payment events. */
export function useLive() {
  const qc = useQueryClient();
  useEffect(() => {
    const s = io((process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1').replace('/api/v1', ''), { auth: { token: token() } });
    s.onAny(ev => { if (ev.startsWith('booking.')) { qc.invalidateQueries({ queryKey: ['queue'] }); qc.invalidateQueries({ queryKey: ['updates'] }); } if (ev.startsWith('payment.')) qc.invalidateQueries({ queryKey: ['payments'] }); });
    return () => { s.disconnect(); };
  }, [qc]);
}
