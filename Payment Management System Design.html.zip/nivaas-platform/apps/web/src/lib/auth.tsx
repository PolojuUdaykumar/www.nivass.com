'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import { api, clearTokens, setTokens } from './api';
type U = { id: string; name: string; role: string; departmentId: string | null } | null;
const C = createContext<{ user: U; login: (l: string, p: string) => Promise<void>; logout: () => Promise<void> }>(null as any);
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<U>(null);
  useEffect(() => { const u = sessionStorage.getItem('u'); if (u) setUser(JSON.parse(u)); }, []);
  const login = async (login: string, password: string) => { const r = await api('/auth/login', { method: 'POST', json: { login, password } }); setTokens(r.accessToken, r.refreshToken); sessionStorage.setItem('u', JSON.stringify(r.user)); setUser(r.user); };
  const logout = async () => { await api('/auth/logout', { method: 'POST', json: {} }).catch(() => {}); clearTokens(); sessionStorage.removeItem('u'); setUser(null); };
  return <C.Provider value={{ user, login, logout }}>{children}</C.Provider>;
}
export const useAuth = () => useContext(C);
export const isAdmin = (r?: string) => ['super_admin', 'admin', 'ops_admin'].includes(r || '');
