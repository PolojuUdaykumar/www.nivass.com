'use client';
const BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1';
let access: string | null = typeof window !== 'undefined' ? sessionStorage.getItem('at') : null;
export const setTokens = (a: string, r?: string) => { access = a; sessionStorage.setItem('at', a); if (r) localStorage.setItem('rt', r); };
export const clearTokens = () => { access = null; sessionStorage.removeItem('at'); localStorage.removeItem('rt'); };
export const token = () => access;
async function refresh() { const rt = localStorage.getItem('rt'); if (!rt) return false; const r = await fetch(BASE + '/auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken: rt }) }); if (!r.ok) return false; const j = await r.json(); setTokens(j.accessToken, j.refreshToken); return true; }
export async function api<T = any>(path: string, opt: RequestInit & { json?: unknown } = {}, retry = true): Promise<T> {
  const headers: any = { ...(opt.headers || {}) }; if (access) headers.Authorization = 'Bearer ' + access;
  let body = opt.body; if (opt.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opt.json); }
  const r = await fetch(BASE + path, { ...opt, headers, body });
  if (r.status === 401 && retry && (await refresh())) return api(path, opt, false);
  if (!r.ok) { const e = await r.json().catch(() => ({ message: r.statusText })); throw new Error(e.message || 'Request failed'); }
  const ct = r.headers.get('content-type') || ''; return (ct.includes('json') ? r.json() : (r.blob() as any));
}
export async function download(path: string, name: string) { const b: Blob = await api(path); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; a.click(); URL.revokeObjectURL(a.href); }
