'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useAuth, isAdmin } from '@/lib/auth';
import { useLive } from '@/lib/live';
const TABS = [['queue', 'Booking queue'], ['payments', 'Payments'], ['inventory', 'Inventory'], ['audit', 'Audit log']] as const;
export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth(); const p = usePathname(); const r = useRouter();
  useEffect(() => { if (user === null && !sessionStorage.getItem('u')) r.replace('/login'); }, [user, r]);
  useLive();
  if (!user) return null;
  if (!isAdmin(user.role) && user.role !== 'finance') return <main className="p-10">Not allowed.</main>;
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 bg-white/60 backdrop-blur-xl border-b border-white/80">
        <div className="mx-auto max-w-[1400px] px-5 h-14 flex items-center justify-between"><b>Nivaas operations console</b>
          <div className="flex items-center gap-3 text-sm"><span className="pill bg-accent-50 text-accent-700">{user.role.replace('_', ' ')}{user.departmentId ? ' · ' + user.departmentId : ''}</span><span>{user.name}</span><button className="btn-secondary" onClick={async () => { await logout(); r.push('/login'); }}>Log out</button></div></div>
        <nav className="mx-auto max-w-[1400px] px-5 pb-2 flex gap-1 flex-wrap">{TABS.map(([k, l]) => <Link key={k} href={'/admin/' + k} className={'btn no-underline ' + (p.startsWith('/admin/' + k) ? 'bg-accent text-white' : 'text-slate-700 hover:bg-accent-50')}>{l}</Link>)}</nav>
      </header>
      <main className="mx-auto max-w-[1400px] px-5 py-6 flex flex-col gap-4">{children}</main>
    </div>
  );
}
