'use client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { formatINR } from '@nivaas/shared';
import { api } from '@/lib/api';
export default function Payments() {
  const qc = useQueryClient(); const { data = [] } = useQuery({ queryKey: ['payments'], queryFn: () => api('/payments') });
  const verify = useMutation({ mutationFn: (id: string) => api(`/payments/${id}/verify`, { method: 'POST' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['payments'] }) });
  return (<><h1 className="text-2xl font-bold">Payments</h1>
    <div className="card p-0 overflow-x-auto"><table className="t min-w-[900px]"><thead><tr><th>Payment</th><th>Booking</th><th>Purpose</th><th>Method</th><th className="text-right">Amount</th><th>Status</th><th>Recorded / verified</th><th></th></tr></thead><tbody>
      {data.map((p: any) => <tr key={p.id}><td className="font-mono text-xs">{p.id}</td><td className="font-mono text-xs">{p.bookingId}</td><td>{p.purpose.replace('_', ' ')}</td><td className="uppercase">{p.method}</td><td className="text-right">{formatINR(p.duePaise)}</td><td><span className="pill bg-slate-100">{p.status.replace(/_/g, ' ')}</span></td><td className="text-xs">{p.recordedBy}{p.verifiedBy ? ' · ' + p.verifiedBy : ''}</td>
        <td>{p.status === 'awaiting_verification' && <button className="btn-primary !min-h-[30px] text-xs" onClick={() => verify.mutate(p.id)}>Verify</button>}</td></tr>)}
    </tbody></table></div></>);
}
