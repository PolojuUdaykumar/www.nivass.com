'use client';
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { BOOKING_LABEL, formatINR } from '@nivaas/shared';
import { api } from '@/lib/api';
const KIND = (b: any) => b.status === 'cancelled' ? ['Cancelled by customer', '#e11d48'] : b.shiftReason && !b.technicianId ? ['Shifted · re-assign', '#ea580c'] : b.invoice || b.workDoneAt ? ['Work completed', '#16a34a'] : !b.technicianId ? ['New booking', '#2563eb'] : b.startedAt ? ['Work started', '#7c3aed'] : b.acceptedAt ? ['Accepted · not started', '#0d9488'] : ['Work pending', '#d97706'];
export default function Queue() {
  const qc = useQueryClient(); const [q, setQ] = useState('');
  const { data: rows = [] } = useQuery({ queryKey: ['queue', q], queryFn: () => api('/bookings?q=' + encodeURIComponent(q)) });
  const { data: techs = [] } = useQuery({ queryKey: ['techs'], queryFn: () => api('/technicians') });
  const { data: upd = [] } = useQuery({ queryKey: ['updates'], queryFn: () => api('/bookings/tech-updates') });
  const inv = () => qc.invalidateQueries({ queryKey: ['queue'] });
  const assign = useMutation({ mutationFn: (v: { id: string; t: string }) => api(`/bookings/${v.id}/assign`, { method: 'PUT', json: { technicianId: v.t } }), onSuccess: inv });
  const labour = useMutation({ mutationFn: (v: { id: string; p: number }) => api(`/bookings/${v.id}/labour`, { method: 'PUT', json: { paise: v.p } }), onSuccess: inv });
  const comment = useMutation({ mutationFn: (v: { id: string; text: string }) => api(`/bookings/${v.id}/comment`, { method: 'PUT', json: { text: v.text } }), onSuccess: () => { inv(); qc.invalidateQueries({ queryKey: ['updates'] }); } });
  const [edit, setEdit] = useState<{ id: string; v: string } | null>(null);
  return (<>
    <div className="flex justify-between items-end gap-3 flex-wrap"><div><h1 className="text-2xl font-bold">Booking queue</h1><div className="text-xs text-slate-500">Newest bookings first · live</div></div>
      <input className="input max-w-sm" placeholder="Search booking, customer" value={q} onChange={e => setQ(e.target.value)} /></div>
    <section className="card flex flex-col gap-2 ring-1 ring-accent-300"><b>Technician updates <span className="pill bg-slate-100">{upd.length}</span></b>
      {!upd.length && <div className="text-sm text-slate-500">No technician comments or shifted work yet.</div>}
      <div className="grid gap-2 grid-cols-[repeat(auto-fill,minmax(300px,1fr))]">{upd.map((u: any) => <button key={u.id} onClick={() => setQ(u.id)} className="text-left rounded-ctl ring-1 ring-slate-200 p-3 bg-white/70 hover:ring-accent">
        <div className="flex justify-between"><span className={'pill ' + (u.shiftReason ? 'bg-orange-100 text-orange-700' : 'bg-teal-100 text-teal-700')}>{u.shiftReason ? 'Work shifted' : 'Technician comment'}</span><span className="font-mono text-xs text-slate-400">{u.id}</span></div>
        <div className="text-sm mt-1">{u.shiftReason ? `${u.shiftFrom} → ${u.shiftTo} · Reason: ${u.shiftReason}` : u.techNote}</div></button>)}</div>
    </section>
    <div className="card p-0 overflow-x-auto"><table className="t min-w-[1240px]"><thead><tr><th>Booking</th><th>Customer</th><th>Service</th><th>Slot</th><th>Status</th><th>Comment · Shift</th><th>Labour</th><th>Technician</th></tr></thead><tbody>
      {rows.map((b: any) => { const [k, c] = KIND(b); return (<tr key={b.id} style={{ background: c + '0d' }}>
        <td style={{ borderLeft: '4px solid ' + c }}><div className="font-mono text-xs">{b.id}</div><span className="pill" style={{ color: c, background: c + '1f' }}>{k}</span></td>
        <td>{b.customer?.name}<div className="text-xs text-slate-500">{b.customer?.phone}</div></td>
        <td>{b.subService}<div><span className="pill bg-slate-100">{b.type}</span></div></td>
        <td className="whitespace-nowrap text-xs">{b.preferredDate?.slice(0, 10)} · {b.preferredSlot}</td>
        <td>{BOOKING_LABEL[b.status as keyof typeof BOOKING_LABEL]}</td>
        <td className="min-w-[230px]">{edit?.id === b.id ? <div className="flex flex-col gap-1"><textarea className="input text-xs min-h-[56px]" value={edit.v} onChange={e => setEdit({ id: b.id, v: e.target.value })} /><div className="flex gap-1"><button className="btn-primary !min-h-[28px] !px-2 text-xs" onClick={() => { comment.mutate({ id: b.id, text: edit.v.trim() }); setEdit(null); }}>Save</button><button className="btn-secondary !min-h-[28px] !px-2 text-xs" onClick={() => setEdit(null)}>Cancel</button></div></div>
          : <div className="flex flex-col gap-1">{b.techNote ? <div className="text-xs rounded-md bg-teal-50 text-teal-800 p-1.5">{b.techNote}<div className="opacity-70">{b.techNoteBy}</div></div> : <span className="text-xs text-slate-400">No comment</span>}<button className="text-xs text-accent text-left" onClick={() => setEdit({ id: b.id, v: b.techNote || '' })}>Edit comment</button>
            {b.shiftReason && <div className="text-xs rounded-md bg-orange-50 text-orange-800 p-1.5"><b>Work shifted · {b.shiftFrom} → {b.shiftTo}</b><div>Reason: {b.shiftReason}</div><div className="opacity-70">{b.shiftBy}</div></div>}</div>}</td>
        <td><form className="flex gap-1" onSubmit={e => { e.preventDefault(); const v = Number(new FormData(e.currentTarget).get('l')); if (v >= 0) labour.mutate({ id: b.id, p: Math.round(v * 100) }); }}><input name="l" className="input !w-24 !min-h-[32px]" defaultValue={b.labourPaise != null ? b.labourPaise / 100 : ''} placeholder="₹" /><button className="btn-secondary !min-h-[32px] !px-2 text-xs">Save</button></form>{b.labourPaise != null && <div className="text-xs text-slate-500">{formatINR(b.labourPaise)}</div>}</td>
        <td><select className="input !min-h-[34px]" value={b.technicianId || ''} onChange={e => e.target.value && assign.mutate({ id: b.id, t: e.target.value })}><option value="">Unassigned</option>{techs.map((t: any) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>
          <div className="text-xs mt-1">{b.technicianId ? (b.acceptedAt ? 'Accepted' : 'Awaiting acceptance') : ''}</div></td>
      </tr>); })}
    </tbody></table></div>
  </>);
}
