'use client';
import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { formatINR } from '@nivaas/shared';
import { api, download } from '@/lib/api';
import { useAuth, isAdmin } from '@/lib/auth';
const st = (it: any) => Number(it.stock) === 0 ? ['Out of Stock', '#e11d48'] : Number(it.stock) <= Number(it.minStock) ? ['Low Stock', '#d97706'] : ['In Stock', '#16a34a'];
export default function Inventory() {
  const { user } = useAuth(); const qc = useQueryClient();
  const { data = [] } = useQuery({ queryKey: ['inv'], queryFn: () => api('/inventory') });
  const [pv, setPv] = useState<any>(null); const [mode, setMode] = useState<'add' | 'set'>('add'); const [file, setFile] = useState<File | null>(null); const [err, setErr] = useState('');
  const preview = async (f: File, m = mode) => { setErr(''); const fd = new FormData(); fd.append('file', f); fd.append('mode', m); try { setPv(await api('/inventory/import/preview', { method: 'POST', body: fd })); } catch (e: any) { setErr(e.message); } };
  const commit = async () => { await api('/inventory/import/commit', { method: 'POST', json: { importId: pv.importId } }); setPv(null); qc.invalidateQueries({ queryKey: ['inv'] }); };
  return (<>
    <div className="flex justify-between items-end flex-wrap gap-2"><h1 className="text-2xl font-bold">Inventory</h1>
      {isAdmin(user?.role) && <div className="flex gap-2"><button className="btn-secondary" onClick={() => download('/inventory/import/template', 'nivaas-stock-import-template.xlsx')}>Import template</button>
        <label className="btn-primary cursor-pointer">Import Excel<input hidden type="file" accept=".xlsx,.xls,.csv" onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) { setFile(f); preview(f); } }} /></label></div>}</div>
    {err && <div className="text-sm text-rose-600">{err}</div>}
    <div className="card p-0 overflow-x-auto"><table className="t min-w-[900px]"><thead><tr><th>SKU</th><th>Product</th><th>Dept</th><th className="text-right">Stock</th><th className="text-right">Cost</th><th className="text-right">Price</th><th>Status</th><th>Supplier</th></tr></thead><tbody>
      {data.map((it: any) => { const [l, c] = st(it); return <tr key={it.sku}><td className="font-mono text-xs">{it.sku}</td><td>{it.name}<div className="text-xs text-slate-500">{[it.partNo, it.brand].filter(Boolean).join(' · ')}</div></td><td>{it.departmentId}</td><td className="text-right">{Number(it.stock)} {it.unit}</td><td className="text-right">{formatINR(it.costPaise)}</td><td className="text-right">{formatINR(it.pricePaise)}</td><td><span className="pill" style={{ color: c, background: c + '1f' }}>{l}</span></td><td>{it.supplier}</td></tr>; })}
    </tbody></table></div>
    {pv && <div className="fixed inset-0 z-40 bg-slate-900/30 backdrop-blur-sm grid place-items-center p-4"><div className="card !bg-white/90 w-full max-w-4xl flex flex-col gap-3 rounded-dlg">
      <b className="text-lg">Import stock · {file?.name}</b>
      <div className="flex gap-2"><span className="pill bg-green-100 text-green-700">{pv.nNew} new</span><span className="pill bg-blue-100 text-blue-700">{pv.nUpd} update</span><span className="pill bg-rose-100 text-rose-700">{pv.nErr} errors (skipped)</span></div>
      <div className="flex gap-2 text-sm">{(['add', 'set'] as const).map(m => <button key={m} className={m === mode ? 'btn-primary' : 'btn-secondary'} onClick={() => { setMode(m); if (file) preview(file, m); }}>{m === 'add' ? 'Add to current stock (stock-in)' : 'Replace current stock (stock count)'}</button>)}</div>
      <div className="overflow-auto max-h-[46vh]"><table className="t text-xs"><thead><tr><th>Row</th><th>Result</th><th>Product</th><th>Dept</th><th className="text-right">Qty</th><th className="text-right">After</th><th>Note</th></tr></thead><tbody>
        {pv.rows.slice(0, 300).map((x: any) => <tr key={x.row}><td>{x.row}</td><td><span className={'pill ' + (x.result === 'error' ? 'bg-rose-100 text-rose-700' : x.result === 'new' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700')}>{x.result}</span></td><td>{x.data?.name || '—'}</td><td>{x.data?.department}</td><td className="text-right">{x.data?.qty ?? '—'}</td><td className="text-right">{x.stockAfter ?? '—'}</td><td className="text-slate-500">{x.errors.join(', ') || (x.sku ? x.sku : 'New product')}</td></tr>)}
      </tbody></table></div>
      <div className="flex justify-end gap-2"><button className="btn-secondary" onClick={() => setPv(null)}>Cancel</button><button className="btn-primary" disabled={!(pv.nNew + pv.nUpd)} onClick={commit}>Import {pv.nNew + pv.nUpd} rows</button></div>
    </div></div>}
  </>);
}
