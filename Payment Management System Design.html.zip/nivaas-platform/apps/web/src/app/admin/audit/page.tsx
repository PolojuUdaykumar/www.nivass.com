'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api, download } from '@/lib/api';
const PERIODS = [['today', 'Today'], ['yesterday', 'Yesterday'], ['week', 'This week'], ['month', 'This month']] as const;
const GAP: Record<string, [string, string]> = { working: ['Working', '#7c3aed'], idle_before_start: ['Idle before start (travel / waiting)', '#b45309'], took_to_accept: ['Took to accept', '#b45309'], idle_no_work: ['Idle · no work assigned', '#d97706'] };
const DOT: Record<string, string> = { 'Work assigned': '#2563eb', Accepted: '#0d9488', 'Work started': '#7c3aed', 'Work completed': '#16a34a' };
const mm = (m: number) => (m < 60 ? m + ' min' : Math.floor(m / 60) + 'h ' + (m % 60) + 'm');
const t = (x: any) => new Date(x).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
export default function Audit() {
  const [period, setPeriod] = useState<string>('today'); const [sel, setSel] = useState<string | null>(null); const [mode, setMode] = useState<'admin' | 'login' | 'all'>('admin'); const [q, setQ] = useState('');
  const { data: tl = [] } = useQuery({ queryKey: ['tl', period], queryFn: () => api('/reports/timeline?period=' + period) });
  const cur = tl.find((x: any) => x.tech.id === sel) || tl[0];
  const { data: logs = [] } = useQuery({ queryKey: ['audit', mode, q, period], enabled: mode !== 'login', queryFn: () => api(`/audit?mode=${mode}&q=${encodeURIComponent(q)}&period=${period}`) });
  const { data: sess = [] } = useQuery({ queryKey: ['sess', period], enabled: mode === 'login', queryFn: () => api('/audit/sessions?period=' + period) });
  return (<>
    <section className="card flex flex-col gap-3 ring-1 ring-accent-300">
      <div className="flex justify-between flex-wrap gap-2 items-center"><b className="text-lg">Technician time track</b>
        <div className="flex gap-2 flex-wrap">{PERIODS.map(([k, l]) => <button key={k} className={period === k ? 'btn-primary' : 'btn-secondary'} onClick={() => setPeriod(k)}>{l}</button>)}
          <button className="btn-secondary" onClick={() => download('/reports/timeline.xlsx?period=' + period, `technician-timeline-${period}.xlsx`)}>Download Excel</button></div></div>
      <div className="grid gap-2 grid-cols-[repeat(auto-fill,minmax(240px,1fr))]">{tl.map((x: any) => <button key={x.tech.id} onClick={() => setSel(x.tech.id)} className={'text-left rounded-ctl p-3 ring-1 ' + (cur?.tech.id === x.tech.id ? 'ring-2 ring-accent bg-accent-50' : 'ring-slate-200')}>
        <b>{x.tech.name}</b><div className="grid grid-cols-3 gap-1 text-[11px] text-slate-500 mt-1"><div>Jobs<div className="text-base text-slate-900">{x.jobs}</div></div><div>Working<div className="text-base text-slate-900">{mm(x.totals.working)}</div></div><div>Idle<div className="text-base font-semibold text-amber-700">{mm(x.totals.idle_no_work)}</div></div></div></button>)}</div>
      {cur && <div className="rounded-ctl ring-1 ring-slate-200 p-3 flex flex-col gap-1"><b>Work-to-work timeline · {cur.tech.name}</b>
        {cur.items.map((it: any, i: number) => it.kind === 'day' ? <div key={i} className="mt-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">{new Date(it.at).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })}</div>
          : it.kind === 'gap' ? <div key={i} className="ml-5 pl-3 py-1.5 text-xs flex justify-between rounded-r-md" style={{ borderLeft: '2px dashed ' + GAP[it.type][1], color: GAP[it.type][1], background: GAP[it.type][1] + '12', fontWeight: it.live || it.type === 'idle_no_work' ? 700 : 500 }}><span>{GAP[it.type][0]}{it.live ? ' · now' : ''}</span><span>{mm(it.mins)}</span></div>
          : <div key={i} className="flex gap-3 items-start py-1"><div className="w-20 text-right text-sm font-semibold">{new Date(it.at).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' })}</div><span className="mt-1 w-3 h-3 rounded-full" style={{ background: DOT[it.title] }} /><div><div className="text-sm font-semibold">{it.title}</div><div className="text-xs text-slate-500">{it.label}</div></div></div>)}
        {!cur.items.length && <div className="text-sm text-slate-500">No work in this period.</div>}</div>}
    </section>
    <section className="card flex flex-col gap-3"><b className="text-lg">Admin activity</b>
      <div className="flex gap-2 flex-wrap">{([['admin', 'Admin changes'], ['login', 'Login & logout'], ['all', 'All activity']] as const).map(([k, l]) => <button key={k} className={mode === k ? 'btn-primary' : 'btn-secondary'} onClick={() => setMode(k)}>{l}</button>)}
        {mode !== 'login' && <input className="input max-w-xs" placeholder="Search person, action or booking" value={q} onChange={e => setQ(e.target.value)} />}</div>
      <div className="overflow-x-auto">{mode === 'login'
        ? <table className="t min-w-[800px]"><thead><tr><th>Admin</th><th>Role</th><th>Logged in</th><th>Logged out</th><th className="text-right">Duration</th><th>Status</th></tr></thead><tbody>{sess.map((s: any, i: number) => <tr key={i}><td className="font-semibold">{s.admin}</td><td>{s.role}{s.dept ? ' · ' + s.dept : ''}</td><td>{t(s.loggedInAt)}</td><td>{s.loggedOutAt ? t(s.loggedOutAt) : '—'}</td><td className="text-right">{mm(s.minutes)}</td><td>{s.status}</td></tr>)}</tbody></table>
        : <table className="t min-w-[900px]"><thead><tr><th>Time</th><th>Admin</th><th>Role · Dept</th><th>Type</th><th>What changed</th><th>Record</th></tr></thead><tbody>{logs.map((a: any) => <tr key={a.id}><td className="whitespace-nowrap">{t(a.at)}</td><td className="font-semibold">{a.actorName}</td><td>{a.actorRole}{a.departmentId ? ' · ' + a.departmentId : ''}</td><td><span className="pill bg-slate-100">{a.category}</span></td><td>{a.action}</td><td className="font-mono text-xs text-slate-500">{a.recordRef}</td></tr>)}</tbody></table>}</div>
    </section>
  </>);
}
