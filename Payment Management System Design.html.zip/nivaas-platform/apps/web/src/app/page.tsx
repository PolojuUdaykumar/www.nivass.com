import Link from 'next/link';
import { DEPARTMENTS } from '@nivaas/shared';
export default function Home() {
  return (
    <main className="mx-auto max-w-6xl px-5 py-10 flex flex-col gap-10">
      <header className="flex items-center justify-between"><div className="text-xl font-bold">Nivaas</div><nav className="flex gap-3"><Link href="/book" className="btn-primary">Book a service</Link><Link href="/login" className="btn-secondary">Staff login</Link></nav></header>
      <section className="flex flex-col gap-3 max-w-2xl"><h1 className="text-4xl font-bold tracking-tight">Trusted home repairs in Pune</h1><p className="text-slate-600 text-lg">Book a verified technician. Pay the visit fee only after the work is approved.</p></section>
      <section className="grid gap-3 grid-cols-[repeat(auto-fill,minmax(160px,1fr))]">
        {DEPARTMENTS.map(d => <Link key={d.id} href={'/book?dept=' + d.id} className="card flex flex-col gap-2 hover:ring-2 hover:ring-accent no-underline text-slate-900"><img src={'/assets/3d1-' + d.id + '.png'} alt="" className="h-20 object-contain" /><span className="font-semibold">{d.name}</span></Link>)}
      </section>
    </main>
  );
}
