'use client';
import { useState } from 'react';
import { DEPARTMENTS } from '@nivaas/shared';
import { api, setTokens } from '@/lib/api';
/** Customer booking on web: phone OTP → details → submit. (Media upload via /files/presign.) */
export default function Book() {
  const [step, setStep] = useState<'phone' | 'otp' | 'form' | 'done'>('phone'); const [phone, setPhone] = useState(''); const [otp, setOtp] = useState(''); const [err, setErr] = useState(''); const [id, setId] = useState('');
  const [f, setF] = useState({ departmentId: 'plumb', subService: '', type: 'standard', date: new Date(Date.now() + 864e5).toISOString().slice(0, 10), slot: '9 am – 12 pm', addressId: '', description: '' });
  const run = (fn: () => Promise<void>) => async (e: any) => { e.preventDefault(); setErr(''); try { await fn(); } catch (x: any) { setErr(x.message); } };
  return (<main className="mx-auto max-w-lg p-5"><div className="card flex flex-col gap-3"><h1 className="text-2xl font-bold">Book a service</h1>
    {step === 'phone' && <form className="flex flex-col gap-3" onSubmit={run(async () => { await api('/auth/otp/send', { method: 'POST', json: { phone } }); setStep('otp'); })}><input className="input" inputMode="numeric" placeholder="Mobile number" value={phone} onChange={e => setPhone(e.target.value)} /><button className="btn-primary justify-center">Send OTP</button></form>}
    {step === 'otp' && <form className="flex flex-col gap-3" onSubmit={run(async () => { const r = await api('/auth/otp/verify', { method: 'POST', json: { phone, otp } }); setTokens(r.accessToken, r.refreshToken); setStep('form'); })}><input className="input" inputMode="numeric" placeholder="6-digit OTP" value={otp} onChange={e => setOtp(e.target.value)} /><button className="btn-primary justify-center">Verify</button></form>}
    {step === 'form' && <form className="flex flex-col gap-3" onSubmit={run(async () => { const b = await api('/bookings', { method: 'POST', json: { ...f, mediaIds: [] } }); setId(b.id); setStep('done'); })}>
      <select className="input" value={f.departmentId} onChange={e => setF({ ...f, departmentId: e.target.value })}>{DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
      <input className="input" placeholder="Problem (e.g. Tap leaking)" value={f.subService} onChange={e => setF({ ...f, subService: e.target.value })} />
      <div className="flex gap-2">{['standard', 'urgent'].map(t => <button type="button" key={t} className={f.type === t ? 'btn-primary' : 'btn-secondary'} onClick={() => setF({ ...f, type: t })}>{t}</button>)}</div>
      <input className="input" type="date" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} />
      <select className="input" value={f.slot} onChange={e => setF({ ...f, slot: e.target.value })}>{['9 am – 12 pm', '12 – 4 pm', '4 – 8 pm'].map(s => <option key={s}>{s}</option>)}</select>
      <input className="input" placeholder="Address ID (from saved addresses)" value={f.addressId} onChange={e => setF({ ...f, addressId: e.target.value })} />
      <textarea className="input min-h-[80px] py-2" placeholder="Describe the problem" value={f.description} onChange={e => setF({ ...f, description: e.target.value })} />
      <button className="btn-primary justify-center">Confirm booking</button></form>}
    {step === 'done' && <div>Booking <b className="font-mono">{id}</b> received. We will assign a technician shortly.</div>}
    {err && <div className="text-sm text-rose-600">{err}</div>}
  </div></main>);
}
