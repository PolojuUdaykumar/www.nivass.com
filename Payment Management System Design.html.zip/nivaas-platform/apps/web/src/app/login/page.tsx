'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth';
export default function Login() {
  const { login } = useAuth(); const r = useRouter(); const [l, setL] = useState(''); const [p, setP] = useState(''); const [err, setErr] = useState('');
  return (
    <main className="min-h-screen grid place-items-center p-5"><form className="card w-full max-w-sm flex flex-col gap-3" onSubmit={async e => { e.preventDefault(); setErr(''); try { await login(l, p); r.push('/admin/queue'); } catch (x: any) { setErr(x.message); } }}>
      <h1 className="text-2xl font-bold">Staff login</h1>
      <input className="input" placeholder="Email or login ID" value={l} onChange={e => setL(e.target.value)} />
      <input className="input" type="password" placeholder="Password" value={p} onChange={e => setP(e.target.value)} />
      {err && <div className="text-sm text-rose-600">{err}</div>}
      <button className="btn-primary justify-center">Sign in</button>
    </form></main>
  );
}
