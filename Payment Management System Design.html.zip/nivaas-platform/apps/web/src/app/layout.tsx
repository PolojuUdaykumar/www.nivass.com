import './globals.css';
import Providers from './providers';
export const metadata = { title: 'Nivaas Home Services · Pune', description: 'Plumber, electrician, AC, carpenter, painting, RO and more — book a verified technician in Pune.' };
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body><Providers>{children}</Providers></body></html>;
}
