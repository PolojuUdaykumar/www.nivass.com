import { PrismaClient } from '@prisma/client';
import * as argon2 from 'argon2';
import { DEPARTMENTS } from '@nivaas/shared';
const db = new PrismaClient();
(async () => {
  for (const d of DEPARTMENTS) await db.department.upsert({ where: { id: d.id }, update: {}, create: { id: d.id, name: d.name, code: d.code, inspectionPriced: !!(d as any).inspection } });
  await db.settings.upsert({ where: { id: 1 }, update: {}, create: { visitPaise: 10000, urgentPaise: 20000, urgentMode: 'flat', creditOnApproval: true, taxPct: 0, cancelHours: 2, upiVpa: 'nivaas@okicici', upiName: 'Nivaas Home Services' } });
  const pw = await argon2.hash('ChangeMe@123');
  await db.user.upsert({ where: { email: 'anita@nivaas.in' }, update: {}, create: { role: 'super_admin', name: 'Anita Desai', email: 'anita@nivaas.in', passwordHash: pw } });
  await db.user.upsert({ where: { email: 'mohit@nivaas.in' }, update: {}, create: { role: 'admin', name: 'Mohit Singh', email: 'mohit@nivaas.in', passwordHash: pw, departmentId: 'plumb' } });
  await db.user.upsert({ where: { email: 'sunita@nivaas.in' }, update: {}, create: { role: 'ops_admin', name: 'Sunita Rao', email: 'sunita@nivaas.in', passwordHash: pw, departmentId: 'elec' } });
  const ravi = await db.user.upsert({ where: { loginId: 'ravi.k' }, update: {}, create: { role: 'technician', name: 'Ravi Kumar', loginId: 'ravi.k', phone: '9890122410', passwordHash: pw, departmentId: 'plumb' } });
  await db.technician.upsert({ where: { userId: ravi.id }, update: {}, create: { userId: ravi.id, code: 'TP-1', skills: ['plumb', 'elec', 'ro'], area: 'Kothrud, Baner, Aundh' } });
  console.log('Seeded. Admin login anita@nivaas.in / ChangeMe@123');
  await db.$disconnect();
})();
