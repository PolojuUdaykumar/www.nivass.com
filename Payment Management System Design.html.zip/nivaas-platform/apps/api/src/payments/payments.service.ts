import { BadRequestException, Injectable } from '@nestjs/common';
import Razorpay from 'razorpay';
import { createHmac } from 'crypto';
import { VERIFIED } from '@nivaas/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../common/audit.service';
import { EventsGateway } from '../common/events.gateway';
import { AuthUser, deptScope } from '../common/auth';
const yy = () => String(new Date().getFullYear()).slice(2);
const rzp = process.env.RAZORPAY_KEY_ID ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID!, key_secret: process.env.RAZORPAY_KEY_SECRET! }) : null;

@Injectable()
export class PaymentsService {
  constructor(private db: PrismaService, private audit: AuditService, private ev: EventsGateway) {}

  /** Technician generates the bill: labour + materials − visit credit + tax. */
  async bill(u: AuthUser, bookingId: string, p: { method: 'upi' | 'cash' | 'sewa'; amountPaise?: number; utr?: string; approver?: string }) {
    const b = await this.db.booking.findUniqueOrThrow({ where: { id: bookingId }, include: { materials: true, payments: true, invoice: true } });
    if (b.technicianId !== u.id) throw new BadRequestException('Not your job');
    if (b.invoice) throw new BadRequestException('Bill already generated');
    if (!b.workDoneAt) throw new BadRequestException('Complete the work first');
    if (b.labourPaise == null) throw new BadRequestException('Admin has not added labour charges yet');
    const cfg = await this.db.settings.findUniqueOrThrow({ where: { id: 1 } });
    const mat = b.materials.reduce((a, m) => a + Math.round(Number(m.qty) * m.pricePaise), 0);
    const feePaid = b.payments.filter(x => x.purpose !== 'final_invoice' && VERIFIED.includes(x.status as any)).reduce((a, x) => a + x.paidPaise, 0);
    const credit = b.creditOnApproval ? Math.min(feePaid, b.labourPaise + mat) : 0;
    const sub = b.labourPaise + mat - credit, tax = Math.round(sub * Number(cfg.taxPct) / 100), total = sub + tax;
    const invId = 'INV-' + yy() + '-' + (await this.db.next('inv', 3100));
    const payId = 'PAY-' + yy() + '-' + (await this.db.next('pay', 5000));
    const status = p.method === 'sewa' ? 'sewa_no_charge' : 'awaiting_verification';
    if (p.method === 'cash' && p.amountPaise !== total) throw new BadRequestException('Cash amount must equal bill total');
    const res = await this.db.$transaction(async tx => {
      const inv = await tx.invoice.create({ data: { id: invId, bookingId, labourPaise: b.labourPaise!, materialsPaise: mat, creditPaise: credit, taxPaise: tax, totalPaise: total, createdBy: u.id } });
      const pay = await tx.payment.create({ data: { id: payId, bookingId, purpose: 'final_invoice', method: p.method, status: status as any, duePaise: total, paidPaise: p.method === 'upi' && !p.utr ? 0 : total, ref: p.utr, sewaApprover: p.approver, recordedBy: u.name } });
      for (const m of b.materials) { await tx.inventoryItem.update({ where: { sku: m.sku }, data: { stock: { decrement: m.qty } } }); await tx.inventoryTx.create({ data: { sku: m.sku, qty: -Number(m.qty), beforeQty: 0, source: 'issue', note: 'Used on ' + bookingId, byUser: u.id } }); }
      await this.audit.log(tx, u, 'payment', `Bill generated · total ₹${total / 100} · ${p.method.toUpperCase()}${p.approver ? ' by ' + p.approver : ''}`, invId, null, { total, method: p.method }, b.departmentId);
      if (status === 'sewa_no_charge') await tx.booking.update({ where: { id: bookingId }, data: { status: 'closed', closedAt: new Date() } });
      return { inv, pay };
    });
    let order = null;
    if (p.method === 'upi' && !p.utr && rzp) order = await rzp.orders.create({ amount: total, currency: 'INR', receipt: payId, notes: { bookingId } });
    if (order) await this.db.payment.update({ where: { id: payId }, data: { gatewayOrderId: order.id } });
    this.ev.emit('payment.updated', b);
    return { ...res, order };
  }

  async verify(u: AuthUser, id: string) {
    const p = await this.db.payment.findUniqueOrThrow({ where: { id }, include: { booking: true } });
    if (p.status !== 'awaiting_verification') throw new BadRequestException('Only payments awaiting verification can be verified');
    if (Object.keys(deptScope(u)).length && p.booking.departmentId !== u.departmentId) throw new BadRequestException('Other department');
    const receipt = 'RCPT-' + (await this.db.next('rcpt', 7000));
    await this.db.$transaction(async tx => {
      await tx.payment.update({ where: { id }, data: { status: 'paid', paidPaise: p.duePaise, verifiedBy: u.name, verifiedAt: new Date(), receiptNo: receipt } });
      await this.audit.log(tx, u, 'payment', `Payment verified · ${p.method.toUpperCase()} ₹${p.duePaise / 100}`, id, { status: p.status }, { status: 'paid' }, p.booking.departmentId);
      await this.closeIfSettled(tx, p.bookingId);
    });
    return { ok: true, receipt };
  }
  async refund(u: AuthUser, id: string, paise: number, reason: string) {
    const p = await this.db.payment.findUniqueOrThrow({ where: { id } });
    if (paise > p.paidPaise - p.refundedPaise) throw new BadRequestException('Refund more than paid');
    const refunded = p.refundedPaise + paise;
    await this.db.payment.update({ where: { id }, data: { refundedPaise: refunded, status: refunded === p.paidPaise ? 'refunded' : 'partially_refunded' } });
    await this.audit.log(this.db, u, 'payment', `Refund ₹${paise / 100}: ${reason}`, id, { refunded: p.refundedPaise }, { refunded });
    return { ok: true };
  }
  private async closeIfSettled(tx: any, bookingId: string) {
    const inv = await tx.invoice.findUnique({ where: { bookingId } }); if (!inv) return;
    const pays = await tx.payment.findMany({ where: { bookingId, purpose: 'final_invoice' } });
    const got = pays.filter((x: any) => VERIFIED.includes(x.status)).reduce((a: number, x: any) => a + x.paidPaise, 0);
    if (got >= inv.totalPaise) await tx.booking.update({ where: { id: bookingId }, data: { status: 'closed', closedAt: new Date() } });
  }
  /** Razorpay webhook — signature verified, idempotent. */
  async webhook(raw: Buffer, sig: string) {
    const exp = createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET || '').update(raw).digest('hex');
    if (exp !== sig) throw new BadRequestException('Bad signature');
    const e = JSON.parse(raw.toString());
    if (e.event !== 'payment.captured') return { ok: true };
    const ent = e.payload.payment.entity;
    const p = await this.db.payment.findFirst({ where: { gatewayOrderId: ent.order_id } }); if (!p || p.status === 'paid') return { ok: true };
    await this.db.$transaction(async tx => {
      await tx.payment.update({ where: { id: p.id }, data: { status: 'paid', paidPaise: ent.amount, ref: ent.id, verifiedBy: 'Gateway · Razorpay', verifiedAt: new Date(), receiptNo: 'RCPT-' + (await this.db.next('rcpt', 7000)) } });
      await this.audit.log(tx, null, 'payment', 'UPI paid via gateway · ₹' + ent.amount / 100, p.id);
      await this.closeIfSettled(tx, p.bookingId);
    });
    return { ok: true };
  }
  async cashPosition(techId: string) {
    const col = await this.db.payment.aggregate({ _sum: { paidPaise: true }, where: { method: 'cash', booking: { technicianId: techId }, status: { in: ['awaiting_verification', 'paid', 'partially_paid'] } } });
    const out = await this.db.cashHandover.aggregate({ _sum: { amountPaise: true }, where: { technicianId: techId } });
    const c = col._sum.paidPaise || 0, h = out._sum.amountPaise || 0; return { collected: c, handedOver: h, balance: c - h };
  }
  async handover(u: AuthUser, to: string, amount: number, note?: string) {
    const cp = await this.cashPosition(u.id); if (amount > cp.balance) throw new BadRequestException('Amount is more than cash in hand');
    const h = await this.db.cashHandover.create({ data: { technicianId: u.id, toName: to, amountPaise: amount, note } });
    await this.audit.log(this.db, u, 'payment', `Cash ₹${amount / 100} handed over to ${to}`, h.id);
    return h;
  }
  list(u: AuthUser, q: any) {
    return this.db.payment.findMany({ where: { booking: deptScope(u) as any, ...(q.method ? { method: q.method } : {}), ...(q.status ? { status: q.status } : {}) }, orderBy: { at: 'desc' }, take: 300 });
  }
}
