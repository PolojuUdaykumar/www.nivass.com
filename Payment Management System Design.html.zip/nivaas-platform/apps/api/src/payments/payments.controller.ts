import { Body, Controller, Get, Headers, Param, Post, Query, Req } from '@nestjs/common';
import { z } from 'zod';
import { Bill, CashHandover } from '@nivaas/shared';
import { PaymentsService } from './payments.service';
import { Me, Public, Roles, AuthUser } from '../common/auth';
import { Zod } from '../common/zod.pipe';
@Controller()
export class PaymentsController {
  constructor(private s: PaymentsService) {}
  @Roles('technician') @Post('bookings/:id/bill') bill(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(Bill)) b: any) { return this.s.bill(u, id, b); }
  @Roles('super_admin', 'admin', 'ops_admin', 'finance') @Get('payments') list(@Me() u: AuthUser, @Query() q: any) { return this.s.list(u, q); }
  @Roles('super_admin', 'admin', 'ops_admin', 'finance') @Post('payments/:id/verify') verify(@Me() u: AuthUser, @Param('id') id: string) { return this.s.verify(u, id); }
  @Roles('super_admin', 'admin', 'ops_admin', 'finance') @Post('payments/:id/refund') refund(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(z.object({ paise: z.number().int().positive(), reason: z.string().min(3) }))) b: any) { return this.s.refund(u, id, b.paise, b.reason); }
  @Roles('technician') @Get('tech/cash') cash(@Me() u: AuthUser) { return this.s.cashPosition(u.id); }
  @Roles('technician') @Post('cash-handovers') handover(@Me() u: AuthUser, @Body(new Zod(CashHandover)) b: any) { return this.s.handover(u, b.to, b.amountPaise, b.note); }
  @Public() @Post('webhooks/razorpay') hook(@Req() r: any, @Headers('x-razorpay-signature') sig: string) { return this.s.webhook(r.rawBody ?? Buffer.from(JSON.stringify(r.body)), sig); }
}
