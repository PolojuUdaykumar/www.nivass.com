import { BadRequestException, Body, Controller, ForbiddenException, Get, Param, Post } from '@nestjs/common';
import * as argon2 from 'argon2';
import { z } from 'zod';
import { phone } from '@nivaas/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../common/audit.service';
import { Me, Roles, AuthUser, deptScope } from '../common/auth';
import { Zod } from '../common/zod.pipe';
const Tech = z.object({ name: z.string().min(3), phone, loginId: z.string().min(3), password: z.string().regex(/^(?=.*[A-Za-z])(?=.*\d).{8,}$/), departmentId: z.string(), skills: z.array(z.string()).min(1), area: z.string().optional() });
const Admin = z.object({ name: z.string().min(3), email: z.string().email(), password: z.string().min(8), role: z.enum(['admin', 'ops_admin', 'support', 'finance']), departmentId: z.string().nullable() });
@Roles('super_admin', 'admin', 'ops_admin')
@Controller()
export class UsersController {
  constructor(private db: PrismaService, private audit: AuditService) {}
  @Get('technicians') techs(@Me() u: AuthUser) { return this.db.user.findMany({ where: { role: 'technician', ...deptScope(u) }, include: { tech: true }, orderBy: { name: 'asc' } }); }
  @Post('technicians') async addTech(@Me() u: AuthUser, @Body(new Zod(Tech)) b: z.infer<typeof Tech>) {
    const dept = u.role === 'super_admin' ? b.departmentId : u.departmentId; if (!dept) throw new BadRequestException('Department required');
    const n = await this.db.next('tech:' + dept, 1);
    const user = await this.db.user.create({ data: { role: 'technician', name: b.name, phone: b.phone, loginId: b.loginId, passwordHash: await argon2.hash(b.password), departmentId: dept, tech: { create: { code: 'T' + dept.slice(0, 1).toUpperCase() + '-' + n, skills: b.skills, area: b.area } } } });
    await this.audit.log(this.db, u, 'admin', 'Technician added · ' + b.name, user.id, null, null, dept);
    return { id: user.id };
  }
  @Get('admins') admins(@Me() u: AuthUser) { return this.db.user.findMany({ where: { role: { in: ['super_admin', 'admin', 'ops_admin', 'support', 'finance'] }, ...(u.role === 'super_admin' ? {} : { OR: [{ id: u.id }, { departmentId: u.departmentId }] }) }, select: { id: true, name: true, email: true, role: true, departmentId: true, active: true } }); }
  @Roles('super_admin', 'admin') @Post('admins') async addAdmin(@Me() u: AuthUser, @Body(new Zod(Admin)) b: z.infer<typeof Admin>) {
    if (u.role === 'admin' && (b.role !== 'ops_admin' || b.departmentId !== u.departmentId)) throw new ForbiddenException('Admins can only create Operations Admins in their department');
    const x = await this.db.user.create({ data: { role: b.role, name: b.name, email: b.email.toLowerCase(), passwordHash: await argon2.hash(b.password), departmentId: b.departmentId } });
    await this.audit.log(this.db, u, 'admin', `Created ${b.role} · ${b.name}`, x.id, null, null, b.departmentId);
    return { id: x.id };
  }
  @Post('users/:id/deactivate') async deactivate(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(z.object({ reason: z.string().min(3), note: z.string().optional() }))) b: any) {
    const t = await this.db.user.findUniqueOrThrow({ where: { id } });
    if (u.role !== 'super_admin' && t.departmentId !== u.departmentId) throw new ForbiddenException();
    await this.db.user.update({ where: { id }, data: { active: false, deactivateReason: b.reason + (b.note ? ': ' + b.note : '') } });
    await this.db.session.updateMany({ where: { userId: id, loggedOutAt: null }, data: { loggedOutAt: new Date(), logoutReason: 'Deactivated' } });
    await this.audit.log(this.db, u, 'admin', `Deactivated ${t.name}: ${b.reason}`, id, null, null, t.departmentId);
    return { ok: true };
  }
}
