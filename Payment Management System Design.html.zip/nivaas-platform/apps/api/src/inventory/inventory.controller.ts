import { Body, Controller, Get, Post, Res, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { z } from 'zod';
import { InventoryService } from './inventory.service';
import { Me, Roles, AuthUser } from '../common/auth';
import { Zod } from '../common/zod.pipe';
@Controller('inventory')
export class InventoryController {
  constructor(private s: InventoryService) {}
  @Get() list(@Me() u: AuthUser) { return this.s.list(u); }
  @Roles('super_admin', 'admin', 'ops_admin') @Get('import/template') tpl(@Res() res: any) {
    res.setHeader('Content-Disposition', 'attachment; filename="nivaas-stock-import-template.xlsx"'); res.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').send(this.s.template()); }
  @Roles('super_admin', 'admin', 'ops_admin') @Post('import/preview') @UseInterceptors(FileInterceptor('file', { limits: { fileSize: 10 * 1024 * 1024 } }))
  preview(@Me() u: AuthUser, @UploadedFile() f: Express.Multer.File, @Body() b: { mode?: 'add' | 'set' }) { return this.s.preview(u, f, b.mode === 'set' ? 'set' : 'add'); }
  @Roles('super_admin', 'admin', 'ops_admin') @Post('import/commit') commit(@Me() u: AuthUser, @Body(new Zod(z.object({ importId: z.string().uuid() }))) b: any) { return this.s.commit(u, b.importId); }
}
