import { BadRequestException, Injectable } from '@nestjs/common';
import * as XLSX from 'xlsx';
import { DEPARTMENTS, StockImportRow } from '@nivaas/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../common/audit.service';
import { AuthUser, deptScope } from '../common/auth';

const norm = (k: string) => String(k).toLowerCase().replace(/[^a-z]/g, '');
const AL: Record<string, string[]> = {
  name: ['name', 'product', 'productname', 'item', 'itemname', 'material'], partNo: ['partno', 'part', 'partnumber', 'model', 'code', 'itemcode'],
  brand: ['brand', 'make', 'company'], department: ['department', 'dept', 'category', 'trade'], unit: ['unit', 'uom'],
  cost: ['costprice', 'cost', 'purchaseprice', 'rate'], price: ['sellingprice', 'price', 'mrp', 'saleprice'],
  qty: ['quantity', 'qty', 'stock', 'instock', 'openingstock'], min: ['minstock', 'min', 'reorderlevel'], supplier: ['supplier', 'vendor'], location: ['location', 'rack', 'bin'],
};
const num = (v: any) => { const n = parseFloat(String(v).replace(/[₹,\s]/g, '')); return Number.isFinite(n) ? n : undefined; };

@Injectable()
export class InventoryService {
  constructor(private db: PrismaService, private audit: AuditService) {}
  list(u: AuthUser) { return this.db.inventoryItem.findMany({ where: deptScope(u), orderBy: { name: 'asc' } }); }

  async preview(u: AuthUser, file: Express.Multer.File, mode: 'add' | 'set') {
    const wb = XLSX.read(file.buffer, { type: 'buffer' }), ws = wb.Sheets[wb.SheetNames[0]];
    const raw: any[] = XLSX.utils.sheet_to_json(ws, { defval: '' }); if (!raw.length) throw new BadRequestException('The file has no rows');
    if (raw.length > 5000) throw new BadRequestException('Max 5000 rows per import');
    const existing = await this.db.inventoryItem.findMany();
    const seen = new Map<string, number>(); let nNew = 0, nUpd = 0, nErr = 0;
    const rows = raw.map((r, i) => {
      const g = (k: string) => { for (const key of Object.keys(r)) if (AL[k].includes(norm(key))) return String(r[key]).trim(); return ''; };
      const deptTxt = norm(g('department')); const dept = deptTxt ? DEPARTMENTS.find(d => norm(d.name) === deptTxt || d.id === deptTxt) : (u.departmentId ? DEPARTMENTS.find(d => d.id === u.departmentId) : undefined);
      const parsed = StockImportRow.safeParse({ name: g('name'), partNo: g('partNo'), brand: g('brand'), department: dept?.id ?? '', unit: g('unit') || 'pcs', cost: num(g('cost')), price: num(g('price')), qty: num(g('qty')), min: num(g('min')), supplier: g('supplier') || undefined, location: g('location') || undefined });
      const errs: string[] = [];
      if (!parsed.success) errs.push(...parsed.error.issues.map(x => x.path[0] + ': ' + x.message));
      const d = parsed.success ? parsed.data : null;
      if (d && Object.keys(deptScope(u)).length && d.department !== u.departmentId) errs.push('Not your department');
      const key = d ? ((d.partNo || d.name) + '|' + d.brand).toLowerCase() : ''; if (d && seen.has(key)) errs.push('Duplicate of row ' + seen.get(key)); else if (d) seen.set(key, i + 2);
      const ex = d ? existing.find(it => d.partNo ? (it.partNo || '').toLowerCase() === d.partNo.toLowerCase() && (!d.brand || (it.brand || '').toLowerCase() === d.brand.toLowerCase()) : it.name.toLowerCase() === d.name.toLowerCase() && (it.brand || '').toLowerCase() === (d.brand || '').toLowerCase()) : undefined;
      if (d && !ex && d.cost == null) errs.push('Cost price needed for new product');
      const result = errs.length ? 'error' : ex ? 'update' : 'new'; result === 'new' ? nNew++ : result === 'update' ? nUpd++ : nErr++;
      return { row: i + 2, result, errors: errs, data: d, sku: ex?.sku, stockBefore: ex ? Number(ex.stock) : 0, stockAfter: d ? (ex && mode === 'add' ? Number(ex.stock) + d.qty : d.qty) : null };
    });
    const imp = await this.db.stockImport.create({ data: { fileName: file.originalname, mode, rowsNew: nNew, rowsUpdated: nUpd, rowsSkipped: nErr, byUser: u.id, preview: rows as any } });
    return { importId: imp.id, nNew, nUpd, nErr, rows };
  }

  async commit(u: AuthUser, importId: string) {
    const imp = await this.db.stockImport.findUniqueOrThrow({ where: { id: importId } });
    if (imp.byUser !== u.id || imp.committed) throw new BadRequestException('Import not available');
    const rows = (imp.preview as any[]).filter(r => r.result !== 'error');
    await this.db.$transaction(async tx => {
      for (const r of rows) {
        const d = r.data;
        if (r.sku) {
          const it = await tx.inventoryItem.findUniqueOrThrow({ where: { sku: r.sku } }); const before = Number(it.stock), after = imp.mode === 'add' ? before + d.qty : d.qty;
          await tx.inventoryItem.update({ where: { sku: r.sku }, data: { stock: after, ...(d.cost != null && { costPaise: Math.round(d.cost * 100) }), ...(d.price != null && { pricePaise: Math.round(d.price * 100) }), ...(d.min != null && { minStock: d.min }), ...(d.supplier && { supplier: d.supplier }), ...(d.location && { location: d.location }) } });
          await tx.inventoryTx.create({ data: { sku: r.sku, qty: after - before, beforeQty: before, costPaise: d.cost != null ? Math.round(d.cost * 100) : it.costPaise, source: 'excel_import', importId, note: 'Excel import · ' + imp.fileName, byUser: u.id } });
        } else {
          const sku = 'NS-' + String(await this.db.next('sku', 1)).padStart(4, '0');
          await tx.inventoryItem.create({ data: { sku, name: d.name, partNo: d.partNo || null, brand: d.brand || null, departmentId: d.department, unit: d.unit, costPaise: Math.round(d.cost * 100), pricePaise: Math.round((d.price ?? d.cost) * 100), stock: d.qty, minStock: d.min ?? 0, supplier: d.supplier, location: d.location, createdBy: u.id } });
          await tx.inventoryTx.create({ data: { sku, qty: d.qty, beforeQty: 0, costPaise: Math.round(d.cost * 100), source: 'excel_import', importId, note: 'Excel import · ' + imp.fileName, byUser: u.id } });
        }
      }
      await tx.stockImport.update({ where: { id: importId }, data: { committed: true } });
      await this.audit.log(tx, u, 'stock', `Stock imported from Excel · ${imp.fileName} · ${imp.rowsNew} new, ${imp.rowsUpdated} updated (${imp.mode === 'set' ? 'stock count' : 'stock-in'})${imp.rowsSkipped ? ', ' + imp.rowsSkipped + ' skipped' : ''}`, 'INVENTORY');
    }, { timeout: 60_000 });
    return { ok: true, imported: rows.length };
  }

  template() {
    const ws = XLSX.utils.aoa_to_sheet([['Name', 'Part no.', 'Brand', 'Department', 'Unit', 'Cost price', 'Selling price', 'Quantity', 'Min stock', 'Supplier', 'Location'], ['PVC pipe 1 inch', 'PVC-25', 'Supreme', 'Plumber', 'pcs', 120, 180, 50, 10, 'Laxmi Traders', 'Rack A2']]);
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'Stock'); return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  }
}
