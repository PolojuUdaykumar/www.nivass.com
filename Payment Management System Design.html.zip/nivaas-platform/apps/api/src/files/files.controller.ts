import { Body, Controller, Post } from '@nestjs/common';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { z } from 'zod';
import { randomUUID } from 'crypto';
import { PrismaService } from '../common/prisma.service';
import { Me, AuthUser } from '../common/auth';
import { Zod } from '../common/zod.pipe';
const s3 = new S3Client({ region: 'auto', endpoint: process.env.S3_ENDPOINT, forcePathStyle: true, credentials: { accessKeyId: process.env.S3_KEY!, secretAccessKey: process.env.S3_SECRET! } });
const OK = /^(image\/(jpeg|png|webp|heic)|video\/(mp4|quicktime)|application\/pdf)$/;
@Controller('files')
export class FilesController {
  constructor(private db: PrismaService) {}
  /** Presigned upload; client PUTs the file directly to storage. */
  @Post('presign') async presign(@Me() u: AuthUser, @Body(new Zod(z.object({ kind: z.enum(['problem', 'after', 'bill', 'qr']), mime: z.string().regex(OK, 'Unsupported file type') }))) b: any) {
    const key = `${b.kind}/${new Date().toISOString().slice(0, 7)}/${randomUUID()}`;
    const url = await getSignedUrl(s3, new PutObjectCommand({ Bucket: process.env.S3_BUCKET, Key: key, ContentType: b.mime }), { expiresIn: 600 });
    const m = await this.db.bookingMedia.create({ data: { kind: b.kind, key, mime: b.mime, uploadedBy: u.id } });
    return { fileId: m.id, uploadUrl: url };
  }
}
