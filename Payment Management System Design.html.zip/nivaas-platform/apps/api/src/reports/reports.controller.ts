import { Controller, Get, Query, Res } from '@nestjs/common';
import * as XLSX from 'xlsx';
import { buildTimeline, periodRange } from '@nivaas/shared';
import { PrismaService } from '../common/prisma.service';
import { Me, Roles, AuthUser, deptScope } from '../common/auth';
type Period = 'today' | 'yesterday' | 'week' | 'month';
const P = (p?: string): Period => (['today', 'yesterday', 'week', 'month'].includes(p!) ? p : 'week') as Period;
const GAP = { working: 'Working', idle_before_start: 'Idle before start (travel / waiting)', took_to_accept: 'Took to accept', idle_no_work: 'Idle · no work assigned' };
const mm = (m: number) => (m < 60 ? m + ' min' : Math.floor(m / 60) + 'h ' + (m % 60) + 'm');

@Roles('super_admin', 'admin', 'ops_admin')
@Controller('reports')
export class ReportsController {
  constructor(private db: PrismaService) {}
  private async techs(u: AuthUser, tech?: string) {
    return this.db.user.findMany({ where: { role: 'technician', ...(deptScope(u)), ...(tech && tech !== 'all' ? { id: tech } : {}) }, select: { id: true, name: true } });
  }
  private async build(u: AuthUser, tech: string | undefined, period: Period) {
    const [from, to] = periodRange(period); const live = to === Infinity;
    const list = await this.techs(u, tech);
    return Promise.all(list.map(async t => {
      const bs = await this.db.booking.findMany({ where: { technicianId: t.id, startedAt: { gte: new Date(from), ...(to !== Infinity && { lt: new Date(to) }) } }, include: { customer: { select: { name: true } } } });
      const jobs = bs.filter(b => b.assignedAt && b.acceptedAt && b.startedAt).map(b => ({ id: b.id, label: b.customer.name + ' · ' + b.subService + ' · ' + b.id, assignedAt: +b.assignedAt!, acceptedAt: +b.acceptedAt!, startedAt: +b.startedAt!, doneAt: b.workDoneAt ? +b.workDoneAt : undefined }));
      return { tech: t, ...buildTimeline(jobs, Date.now(), live) };
    }));
  }
  @Get('timeline') timeline(@Me() u: AuthUser, @Query('tech') tech?: string, @Query('period') period?: string) { return this.build(u, tech, P(period)); }

  @Get('timeline.xlsx') async xlsx(@Me() u: AuthUser, @Res() res: any, @Query('tech') tech?: string, @Query('period') period?: string) {
    const p = P(period), data = await this.build(u, tech, p), t = (x: number) => new Date(x).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
    const rows: any[][] = [['Technician', 'Date', 'Time', 'Event', 'Customer · job', 'Gap / status', 'Gap (min)', 'Gap']];
    const sum: any[][] = [['Technician', 'Jobs', 'Working (min)', 'Idle between jobs (min)', 'Took to accept (min)', 'Idle before start (min)']];
    for (const d of data) {
      let day = '';
      for (const it of d.items) {
        if (it.kind === 'day') day = new Date(it.at).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata', weekday: 'short', day: 'numeric', month: 'short' });
        else if (it.kind === 'point') rows.push([d.tech.name, day, new Date(it.at).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: 'numeric', minute: '2-digit' }), it.title, it.label, '', '', '']);
        else rows.push([d.tech.name, day, '', '', '', GAP[it.type] + (it.live ? ' (now)' : ''), it.mins, mm(it.mins)]);
      }
      rows.push([]); sum.push([d.tech.name, d.jobs, d.totals.working, d.totals.idle_no_work, d.totals.took_to_accept, d.totals.idle_before_start]);
    }
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), 'Timeline'); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sum), 'Summary');
    res.setHeader('Content-Disposition', `attachment; filename="technician-timeline-${p}-${new Date().toISOString().slice(0, 10)}.xlsx"`);
    res.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').send(XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }));
    void t;
  }
}
