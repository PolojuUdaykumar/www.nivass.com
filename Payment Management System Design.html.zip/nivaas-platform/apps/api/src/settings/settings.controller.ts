import { Body, Controller, Get, Put } from '@nestjs/common';
import { z } from 'zod';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../common/audit.service';
import { Me, Public, Roles, AuthUser } from '../common/auth';
import { Zod } from '../common/zod.pipe';
const S = z.object({ visitPaise: z.number().int().min(0), urgentPaise: z.number().int().min(0), urgentMode: z.string(), creditOnApproval: z.boolean(), taxPct: z.number().min(0).max(28), cancelHours: z.number().int().min(0), upiVpa: z.string().optional(), upiName: z.string().optional(), sewaPolicy: z.string().optional() });
const LBL: Record<string, string> = { visitPaise: 'Visit charge', urgentPaise: 'Urgent charge', urgentMode: 'Urgent mode', creditOnApproval: 'Credit on approval', taxPct: 'Tax %', cancelHours: 'Cancel window (hrs)', upiVpa: 'UPI ID', upiName: 'UPI name', sewaPolicy: 'SEWA policy' };
@Controller('settings')
export class SettingsController {
  constructor(private db: PrismaService, private audit: AuditService) {}
  @Public() @Get('public') pub() { return this.db.settings.findUnique({ where: { id: 1 }, select: { visitPaise: true, urgentPaise: true, cancelHours: true, taxPct: true } }); }
  @Roles('super_admin') @Get() get() { return this.db.settings.findUnique({ where: { id: 1 } }); }
  @Roles('super_admin') @Put() async put(@Me() u: AuthUser, @Body(new Zod(S)) b: z.infer<typeof S>) {
    const before: any = await this.db.settings.findUniqueOrThrow({ where: { id: 1 } });
    const fmt = (k: string, v: any) => (k.endsWith('Paise') ? '₹' + v / 100 : String(v));
    const diff = Object.keys(b).filter(k => String(before[k]) !== String((b as any)[k])).map(k => `${LBL[k]} ${fmt(k, before[k])} → ${fmt(k, (b as any)[k])}`);
    const after = await this.db.settings.update({ where: { id: 1 }, data: { ...b, updatedBy: u.id } });
    await this.audit.log(this.db, u, 'admin', 'Pricing updated · ' + (diff.join(', ') || 'no changes'), 'CONFIG', before, after);
    return after;
  }
}
