import { WebSocketGateway, WebSocketServer, OnGatewayConnection } from '@nestjs/websockets';
import { JwtService } from '@nestjs/jwt';
import type { Server, Socket } from 'socket.io';
@WebSocketGateway({ cors: { origin: true } })
export class EventsGateway implements OnGatewayConnection {
  @WebSocketServer() io!: Server;
  constructor(private jwt: JwtService) {}
  handleConnection(s: Socket) {
    try { const u: any = this.jwt.verify(String(s.handshake.auth?.token || '')); s.join('user:' + u.id); if (u.departmentId) s.join('dept:' + u.departmentId); if (u.role === 'super_admin') s.join('dept:all'); }
    catch { s.disconnect(); }
  }
  emit(event: string, b: { id: string; departmentId: string; technicianId?: string | null; customerId?: string }) {
    const rooms = ['dept:' + b.departmentId, 'dept:all', 'booking:' + b.id]; if (b.technicianId) rooms.push('user:' + b.technicianId); if (b.customerId) rooms.push('user:' + b.customerId);
    this.io.to(rooms).emit(event, { id: b.id });
  }
}
