import { SetMetadata, createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { Role } from '@nivaas/shared';
export type AuthUser = { id: string; role: Role; name: string; departmentId: string | null };
export const Public = () => SetMetadata('public', true);
export const Roles = (...r: Role[]) => SetMetadata('roles', r);
export const Me = createParamDecorator((_: unknown, ctx: ExecutionContext): AuthUser => ctx.switchToHttp().getRequest().user);
/** Prisma where-fragment restricting dept-scoped admins to their department. */
export const deptScope = (u: AuthUser) => (['admin', 'ops_admin'].includes(u.role) && u.departmentId ? { departmentId: u.departmentId } : {});
