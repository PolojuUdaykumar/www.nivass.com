import { BadRequestException, PipeTransform } from '@nestjs/common';
import type { ZodSchema } from 'zod';
export class Zod<T> implements PipeTransform { constructor(private s: ZodSchema<T>) {}
  transform(v: unknown) { const r = this.s.safeParse(v); if (!r.success) { const i = r.error.issues[0]; throw new BadRequestException({ code: 'validation', message: i.message, field: i.path.join('.') }); } return r.data; } }
