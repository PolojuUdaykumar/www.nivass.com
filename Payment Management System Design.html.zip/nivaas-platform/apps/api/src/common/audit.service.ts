import { Injectable } from '@nestjs/common';
import { AuditCat, Prisma } from '@prisma/client';
import { PrismaService } from './prisma.service';
import type { AuthUser } from './auth';
@Injectable()
export class AuditService {
  constructor(private db: PrismaService) {}
  log(tx: Prisma.TransactionClient | PrismaService, u: AuthUser | null, category: AuditCat, action: string, recordRef?: string, before?: unknown, after?: unknown, departmentId?: string | null) {
    return tx.auditLog.create({ data: { actorId: u?.id, actorName: u?.name || 'System', actorRole: u?.role as any, departmentId: departmentId ?? u?.departmentId ?? null, category, action, recordRef, before: before as any, after: after as any } });
  }
}
