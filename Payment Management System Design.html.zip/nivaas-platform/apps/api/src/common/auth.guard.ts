import { CanActivate, ExecutionContext, ForbiddenException, Injectable, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private jwt: JwtService, private ref: Reflector) {}
  canActivate(ctx: ExecutionContext) {
    const h = [ctx.getHandler(), ctx.getClass()];
    if (this.ref.getAllAndOverride<boolean>('public', h)) return true;
    const req = ctx.switchToHttp().getRequest();
    const tok = (req.headers.authorization || '').replace(/^Bearer /, '');
    try { req.user = this.jwt.verify(tok); } catch { throw new UnauthorizedException(); }
    const roles = this.ref.getAllAndOverride<string[]>('roles', h);
    if (roles && !roles.includes(req.user.role)) throw new ForbiddenException('Not allowed for your role');
    return true;
  }
}
