import { Injectable, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  async onModuleInit() { await this.$connect(); }
  /** Atomic sequence for human ids (NVP-26-10421, INV-26-3100…) */
  async next(key: string, start: number) {
    const r = await this.$queryRaw<{ value: number }[]>`insert into "Counter"(key, value) values (${key}, ${start}) on conflict (key) do update set value = "Counter".value + 1 returning value`;
    return r[0].value;
  }
}
