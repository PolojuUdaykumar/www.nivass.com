import { Body, Controller, Get, Param, Post, Put, Query } from '@nestjs/common';
import { z } from 'zod';
import { Assign, Comment, Complete, CreateBooking, Labour, Shift } from '@nivaas/shared';
import { BookingsService } from './bookings.service';
import { Me, Roles, AuthUser } from '../common/auth';
import { Zod } from '../common/zod.pipe';
@Controller('bookings')
export class BookingsController {
  constructor(private s: BookingsService) {}
  @Roles('customer', 'super_admin', 'admin', 'ops_admin', 'support') @Post() create(@Me() u: AuthUser, @Body(new Zod(CreateBooking)) b: any) { return this.s.create(u, b); }
  @Get() list(@Me() u: AuthUser, @Query() q: any) { return this.s.list(u, q); }
  @Roles('super_admin', 'admin', 'ops_admin') @Get('tech-updates') updates(@Me() u: AuthUser) { return this.s.techUpdates(u); }
  @Roles('super_admin', 'admin', 'ops_admin') @Put(':id/assign') assign(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(Assign)) b: any) { return this.s.assign(u, id, b.technicianId); }
  @Roles('super_admin', 'admin', 'ops_admin') @Put(':id/labour') labour(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(Labour)) b: any) { return this.s.setLabour(u, id, b.paise); }
  @Roles('technician') @Post(':id/accept') accept(@Me() u: AuthUser, @Param('id') id: string) { return this.s.accept(u, id); }
  @Roles('technician') @Post(':id/reset') reset(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(z.object({ reason: z.string().min(3) }))) b: any) { return this.s.reset(u, id, b.reason); }
  @Roles('technician') @Post(':id/start') start(@Me() u: AuthUser, @Param('id') id: string) { return this.s.start(u, id); }
  @Roles('technician') @Post(':id/complete') complete(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(Complete)) b: any) { return this.s.complete(u, id, b.afterMediaIds); }
  @Roles('technician', 'super_admin', 'admin', 'ops_admin') @Put(':id/comment') comment(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(Comment)) b: any) { return this.s.comment(u, id, b.text); }
  @Roles('technician') @Post(':id/shift') shift(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(Shift)) b: any) { return this.s.shift(u, id, b.toDepartment, b.reason); }
  @Post(':id/cancel') cancel(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(z.object({ reason: z.string().min(3) }))) b: any) { return this.s.cancel(u, id, b.reason); }
  @Roles('technician') @Post(':id/materials') mat(@Me() u: AuthUser, @Param('id') id: string, @Body(new Zod(z.object({ sku: z.string(), qty: z.number().positive() }))) b: any) { return this.s.addMaterial(u, id, b.sku, b.qty); }
}
