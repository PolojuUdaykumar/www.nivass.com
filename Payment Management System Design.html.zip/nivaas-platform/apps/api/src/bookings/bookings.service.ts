import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { DEPARTMENTS, RESET_WINDOW_MS, MIN_AFTER_MEDIA, type CreateBookingDto } from '@nivaas/shared';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../common/audit.service';
import { EventsGateway } from '../common/events.gateway';
import { AuthUser, deptScope } from '../common/auth';

const ADMIN = ['super_admin', 'admin', 'ops_admin'];
const yy = () => String(new Date().getFullYear()).slice(2);

@Injectable()
export class BookingsService {
  constructor(private db: PrismaService, private audit: AuditService, private ev: EventsGateway) {}

  private async get(id: string, u: AuthUser) {
    const b = await this.db.booking.findUnique({ where: { id } });
    if (!b) throw new NotFoundException('Booking not found');
    if (u.role === 'customer' && b.customerId !== u.id) throw new ForbiddenException();
    if (u.role === 'technician' && b.technicianId !== u.id) throw new ForbiddenException('Not your job');
    if (['admin', 'ops_admin'].includes(u.role) && u.departmentId && b.departmentId !== u.departmentId) throw new ForbiddenException('Other department');
    return b;
  }
  /** Run a mutation + event + audit atomically, then broadcast. */
  private async mutate(id: string, u: AuthUser, event: string, cat: any, action: string, data: Prisma.BookingUpdateInput, meta?: any) {
    const before = await this.get(id, u);
    const after = await this.db.$transaction(async tx => {
      const b = await tx.booking.update({ where: { id }, data });
      await tx.bookingEvent.create({ data: { bookingId: id, event, actorId: u.id, meta } });
      await this.audit.log(tx, u, cat, action, id, pick(before, data), pick(b, data), b.departmentId);
      return b;
    });
    this.ev.emit('booking.' + event, after);
    return after;
  }

  async create(u: AuthUser, d: CreateBookingDto) {
    const dept = DEPARTMENTS.find(x => x.id === d.departmentId); if (!dept) throw new BadRequestException('Unknown service');
    const cfg = await this.db.settings.findUniqueOrThrow({ where: { id: 1 } });
    const n = await this.db.next('booking', 10400);
    const id = `NV${dept.code}-${yy()}-${n}`;
    const fee = d.type === 'urgent' ? cfg.urgentPaise : cfg.visitPaise;
    const b = await this.db.$transaction(async tx => {
      const b = await tx.booking.create({ data: { id, customerId: u.id, departmentId: d.departmentId, subService: d.subService, type: d.type, preferredDate: new Date(d.date), preferredSlot: d.slot, addressId: d.addressId, description: d.description, visitFeePaise: fee, creditOnApproval: cfg.creditOnApproval } });
      if (d.mediaIds.length) await tx.bookingMedia.updateMany({ where: { id: { in: d.mediaIds }, uploadedBy: u.id }, data: { bookingId: id } });
      const pid = 'PAY-' + yy() + '-' + (await this.db.next('pay', 5000));
      await tx.payment.create({ data: { id: pid, bookingId: id, purpose: d.type === 'urgent' ? 'urgent_fee' : 'visit_fee', method: 'cash', status: 'pending', duePaise: fee } });
      await tx.bookingEvent.create({ data: { bookingId: id, event: 'created', actorId: u.id } });
      await this.audit.log(tx, u, 'booking', 'Booking created · visit fee pending', id, null, null, d.departmentId);
      return b;
    });
    this.ev.emit('booking.created', b);
    return b;
  }

  list(u: AuthUser, q: { kind?: string; q?: string; filter?: string }) {
    const where: Prisma.BookingWhereInput = { ...deptScope(u) };
    if (u.role === 'customer') where.customerId = u.id;
    if (u.role === 'technician') {
      where.technicianId = u.id;
      if (q.filter === 'new') Object.assign(where, { acceptedAt: null, status: { notIn: ['closed', 'cancelled'] } });
      if (q.filter === 'pending') Object.assign(where, { acceptedAt: { not: null }, invoice: null, status: { notIn: ['closed', 'cancelled'] } });
      if (q.filter === 'done') Object.assign(where, { OR: [{ status: 'closed' }, { invoice: { isNot: null } }] });
      if (q.filter === 'cancel') where.status = 'cancelled';
    }
    if (q.q) where.OR = [{ id: { contains: q.q, mode: 'insensitive' } }, { customer: { name: { contains: q.q, mode: 'insensitive' } } }];
    return this.db.booking.findMany({ where, orderBy: { createdAt: 'desc' }, take: 200, include: { customer: { select: { name: true, phone: true } }, technician: { select: { name: true } }, invoice: true } });
  }

  async assign(u: AuthUser, id: string, techId: string) {
    const t = await this.db.user.findFirst({ where: { id: techId, role: 'technician', active: true } }); if (!t) throw new BadRequestException('Technician not active');
    const b = await this.get(id, u);
    return this.mutate(id, u, 'assigned', 'booking', `${b.technicianId ? 'Reassigned' : 'Assigned'} to ${t.name}`, { technician: { connect: { id: techId } }, assignedAt: new Date(), acceptedAt: null, status: 'technician_assigned' });
  }
  setLabour(u: AuthUser, id: string, paise: number) { return this.mutate(id, u, 'labour', 'booking', 'Labour charges set to ₹' + paise / 100, { labourPaise: paise }); }
  accept(u: AuthUser, id: string) { return this.mutate(id, u, 'accepted', 'tech', 'Accepted job', { acceptedAt: new Date(), status: 'site_visit_scheduled' }); }

  async reset(u: AuthUser, id: string, reason: string) {
    const b = await this.get(id, u);
    if (!b.acceptedAt || Date.now() - b.acceptedAt.getTime() > RESET_WINDOW_MS) throw new BadRequestException('Reset window has ended (2 minutes after accepting).');
    return this.mutate(id, u, 'reset', 'tech', 'Reset by technician: ' + reason, { technician: { disconnect: true }, acceptedAt: null, startedAt: null, status: 'awaiting_confirmation' });
  }
  async start(u: AuthUser, id: string) {
    const b = await this.get(id, u); if (!b.acceptedAt) throw new BadRequestException('Accept the job first');
    return this.mutate(id, u, 'started', 'tech', 'Work started', { startedAt: b.startedAt ?? new Date(), status: 'work_in_progress' });
  }
  async complete(u: AuthUser, id: string, mediaIds: string[]) {
    const n = await this.db.bookingMedia.updateMany({ where: { id: { in: mediaIds }, uploadedBy: u.id }, data: { bookingId: id, kind: 'after' } });
    if (n.count < MIN_AFTER_MEDIA) throw new BadRequestException('Add at least 2 photos or videos of the finished work.');
    return this.mutate(id, u, 'completed', 'tech', `Work completed · ${n.count} photos/videos uploaded`, { workDoneAt: new Date(), status: 'payment_pending' });
  }
  comment(u: AuthUser, id: string, text: string) {
    const who = u.role === 'technician' ? 'Technician comment updated: ' : 'Comment edited by admin: ';
    return this.mutate(id, u, 'comment', u.role === 'technician' ? 'tech' : 'booking', who + (text || '(cleared)'), { techNote: text, techNoteAt: new Date(), techNoteBy: u.name });
  }
  async shift(u: AuthUser, id: string, to: string, reason: string) {
    const b = await this.get(id, u); const from = DEPARTMENTS.find(d => d.id === b.departmentId)!, toD = DEPARTMENTS.find(d => d.id === to);
    if (!toD || toD.id === from.id) throw new BadRequestException('Pick a different department');
    return this.mutate(id, u, 'shifted', 'tech', `Work shifted ${from.name} → ${toD.name}: ${reason}`, { department: { connect: { id: to } }, technician: { disconnect: true }, acceptedAt: null, startedAt: null, workDoneAt: null, status: 'awaiting_confirmation', shiftFrom: from.name, shiftTo: toD.name, shiftReason: reason, shiftBy: u.name, shiftedAt: new Date() });
  }
  async cancel(u: AuthUser, id: string, reason: string) {
    const b = await this.get(id, u); const cfg = await this.db.settings.findUniqueOrThrow({ where: { id: 1 } });
    if (u.role === 'customer' && b.preferredDate && b.preferredDate.getTime() - Date.now() < cfg.cancelHours * 36e5) throw new BadRequestException(`Cancel at least ${cfg.cancelHours} hours before the visit`);
    return this.mutate(id, u, 'cancelled', 'booking', 'Booking cancelled: ' + reason, { status: 'cancelled', cancelReason: reason });
  }
  async addMaterial(u: AuthUser, id: string, sku: string, qty: number) {
    await this.get(id, u); const it = await this.db.inventoryItem.findUniqueOrThrow({ where: { sku } });
    const m = await this.db.bookingMaterial.create({ data: { bookingId: id, sku, qty, pricePaise: it.pricePaise, addedBy: u.id } });
    await this.audit.log(this.db, u, 'stock', `Material added · ${it.name} × ${qty}`, id);
    return m;
  }
  techUpdates(u: AuthUser) {
    return this.db.booking.findMany({ where: { ...deptScope(u), OR: [{ techNote: { not: null } }, { shiftReason: { not: null } }] }, orderBy: [{ techNoteAt: 'desc' }, { shiftedAt: 'desc' }], take: 30, select: { id: true, techNote: true, techNoteAt: true, techNoteBy: true, shiftFrom: true, shiftTo: true, shiftReason: true, shiftBy: true, shiftedAt: true, technicianId: true } });
  }
}
function pick(o: any, keys: object) { const r: any = {}; for (const k of Object.keys(keys)) if (k in o) r[k] = o[k]; return r; }
