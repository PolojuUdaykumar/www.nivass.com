import { Controller, Get, Query } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { periodRange } from '@nivaas/shared';
import { PrismaService } from '../common/prisma.service';
import { Me, Roles, AuthUser } from '../common/auth';
const ADM = ['super_admin', 'admin', 'ops_admin'] as const;
@Roles(...ADM)
@Controller('audit')
export class AuditController {
  constructor(private db: PrismaService) {}
  private scope(u: AuthUser): Prisma.AuditLogWhereInput { return u.role === 'super_admin' || !u.departmentId ? {} : { departmentId: u.departmentId }; }
  /** mode=admin: only admin actors, no logins · mode=all: everything · category & q filters */
  @Get() list(@Me() u: AuthUser, @Query() q: { mode?: string; category?: any; q?: string; period?: any; cursor?: string }) {
    const [from] = q.period ? periodRange(q.period) : [0];
    const where: Prisma.AuditLogWhereInput = { ...this.scope(u), at: { gte: new Date(from) },
      ...(q.mode === 'admin' && { actorRole: { in: [...ADM] }, category: { not: 'auth' } }),
      ...(q.category && { category: q.category }),
      ...(q.q && { OR: [{ actorName: { contains: q.q, mode: 'insensitive' } }, { action: { contains: q.q, mode: 'insensitive' } }, { recordRef: { contains: q.q, mode: 'insensitive' } }] }) };
    return this.db.auditLog.findMany({ where, orderBy: { id: 'desc' }, take: 100, ...(q.cursor && { cursor: { id: BigInt(q.cursor) }, skip: 1 }) }).then(r => r.map(x => ({ ...x, id: String(x.id) })));
  }
  /** Admin login/logout sessions with duration */
  @Get('sessions') async sessions(@Me() u: AuthUser, @Query('period') period?: any) {
    const [from] = period ? periodRange(period) : [0];
    const s = await this.db.session.findMany({ where: { loggedInAt: { gte: new Date(from) }, user: { role: { in: [...ADM] }, ...(u.role !== 'super_admin' && u.departmentId ? { departmentId: u.departmentId } : {}) } }, include: { user: { select: { name: true, role: true, departmentId: true } } }, orderBy: { loggedInAt: 'desc' }, take: 300 });
    return s.map(x => ({ admin: x.user.name, role: x.user.role, dept: x.user.departmentId, loggedInAt: x.loggedInAt, loggedOutAt: x.loggedOutAt, minutes: Math.round(((x.loggedOutAt ?? new Date()).getTime() - x.loggedInAt.getTime()) / 6e4), status: x.loggedOutAt ? x.logoutReason : 'Active / not logged out', ip: x.ip }));
  }
}
