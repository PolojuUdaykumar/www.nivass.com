import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import { randomBytes, createHash } from 'crypto';
import { PrismaService } from '../common/prisma.service';
import { AuditService } from '../common/audit.service';

const sha = (s: string) => createHash('sha256').update(s).digest('hex');
const otps = new Map<string, { code: string; exp: number; tries: number }>(); // use Redis in production

@Injectable()
export class AuthService {
  constructor(private db: PrismaService, private jwt: JwtService, private audit: AuditService) {}

  async sendOtp(phone: string) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    otps.set(phone, { code, exp: Date.now() + 5 * 60_000, tries: 0 });
    // TODO: send via SMS provider (MSG91/Twilio). Never log the code in production.
    return { sent: true };
  }
  async verifyOtp(phone: string, code: string, meta: Meta) {
    const o = otps.get(phone);
    if (!o || o.exp < Date.now() || ++o.tries > 5 || o.code !== code) throw new UnauthorizedException('Invalid or expired OTP');
    otps.delete(phone);
    const user = await this.db.user.upsert({ where: { phone }, update: {}, create: { phone, role: 'customer', name: 'Customer' } });
    return this.issue(user, meta);
  }
  async login(idOrEmail: string, password: string, meta: Meta) {
    const user = await this.db.user.findFirst({ where: { OR: [{ email: idOrEmail.toLowerCase() }, { loginId: idOrEmail }] } });
    if (!user || !user.passwordHash || !(await argon2.verify(user.passwordHash, password))) throw new UnauthorizedException('Wrong login or password');
    if (!user.active) throw new UnauthorizedException('Account deactivated: ' + (user.deactivateReason || 'contact admin'));
    return this.issue(user, meta);
  }
  private async issue(user: any, meta: Meta) {
    const refresh = randomBytes(32).toString('hex');
    const s = await this.db.session.create({ data: { userId: user.id, refreshHash: sha(refresh), ip: meta.ip, userAgent: meta.ua } });
    const claims = { id: user.id, role: user.role, name: user.name, departmentId: user.departmentId, sid: s.id };
    await this.audit.log(this.db, claims as any, 'auth', 'Logged in as ' + user.role, user.id);
    return { accessToken: this.jwt.sign(claims), refreshToken: s.id + '.' + refresh, user: claims };
  }
  async refresh(token: string) {
    const [sid, raw] = token.split('.');
    const s = await this.db.session.findUnique({ where: { id: sid }, include: { user: true } });
    if (!s || s.loggedOutAt || s.refreshHash !== sha(raw)) throw new UnauthorizedException();
    const next = randomBytes(32).toString('hex');
    await this.db.session.update({ where: { id: sid }, data: { refreshHash: sha(next) } }); // rotate
    const u = s.user;
    return { accessToken: this.jwt.sign({ id: u.id, role: u.role, name: u.name, departmentId: u.departmentId, sid }), refreshToken: sid + '.' + next };
  }
  async logout(user: any, reason = 'Logged out') {
    await this.db.session.updateMany({ where: { id: user.sid, loggedOutAt: null }, data: { loggedOutAt: new Date(), logoutReason: reason } });
    await this.audit.log(this.db, user, 'auth', reason, user.id);
    return { ok: true };
  }
  async setPassword(userId: string, pw: string) {
    if (!/^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(pw)) throw new BadRequestException('Password needs 8+ characters with a letter and a number');
    await this.db.user.update({ where: { id: userId }, data: { passwordHash: await argon2.hash(pw) } });
  }
}
type Meta = { ip?: string; ua?: string };
