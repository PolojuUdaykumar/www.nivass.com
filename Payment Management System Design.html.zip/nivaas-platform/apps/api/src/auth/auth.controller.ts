import { Body, Controller, Post, Req } from '@nestjs/common';
import { z } from 'zod';
import { phone } from '@nivaas/shared';
import { AuthService } from './auth.service';
import { Me, Public } from '../common/auth';
import { Zod } from '../common/zod.pipe';
const meta = (r: any) => ({ ip: r.ip, ua: r.headers['user-agent'] });
@Controller('auth')
export class AuthController {
  constructor(private s: AuthService) {}
  @Public() @Post('otp/send') send(@Body(new Zod(z.object({ phone }))) b: { phone: string }) { return this.s.sendOtp(b.phone); }
  @Public() @Post('otp/verify') verify(@Body(new Zod(z.object({ phone, otp: z.string().length(6) }))) b: any, @Req() r: any) { return this.s.verifyOtp(b.phone, b.otp, meta(r)); }
  @Public() @Post('login') login(@Body(new Zod(z.object({ login: z.string().min(3), password: z.string().min(1) }))) b: any, @Req() r: any) { return this.s.login(b.login, b.password, meta(r)); }
  @Public() @Post('refresh') refresh(@Body(new Zod(z.object({ refreshToken: z.string() }))) b: any) { return this.s.refresh(b.refreshToken); }
  @Post('logout') logout(@Me() u: any, @Body() b: { reason?: string }) { return this.s.logout(u, b?.reason === 'switch' ? 'Logged out (switched account)' : 'Logged out'); }
}
