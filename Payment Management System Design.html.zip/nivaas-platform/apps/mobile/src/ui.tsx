import { Pressable, Text, TextInput, View, StyleSheet } from 'react-native';
export const C = { accent: '#5B4BE0', text: '#0f172a', muted: '#64748b', line: '#e2e8f0', bg: '#f5f6fb', new: '#2563eb', accepted: '#0d9488', started: '#7c3aed', done: '#16a34a', idle: '#d97706', danger: '#e11d48' };
export const Btn = ({ title, onPress, kind = 'primary', disabled }: { title: string; onPress: () => void; kind?: 'primary' | 'secondary'; disabled?: boolean }) =>
  <Pressable onPress={onPress} disabled={disabled} style={[s.btn, kind === 'primary' ? { backgroundColor: C.accent } : { backgroundColor: '#fff', borderWidth: 1, borderColor: C.line }, disabled && { opacity: 0.5 }]}><Text style={{ color: kind === 'primary' ? '#fff' : C.text, fontWeight: '700', fontSize: 15 }}>{title}</Text></Pressable>;
export const Input = (p: React.ComponentProps<typeof TextInput>) => <TextInput placeholderTextColor={C.muted} {...p} style={[s.input, p.style]} />;
export const Card = ({ children, style }: any) => <View style={[s.card, style]}>{children}</View>;
export const Pill = ({ label, color }: { label: string; color: string }) => <View style={{ alignSelf: 'flex-start', paddingHorizontal: 9, paddingVertical: 3, borderRadius: 999, backgroundColor: color + '22' }}><Text style={{ color, fontSize: 11, fontWeight: '700' }}>{label}</Text></View>;
const s = StyleSheet.create({
  btn: { minHeight: 48, borderRadius: 12, paddingHorizontal: 18, alignItems: 'center', justifyContent: 'center' },
  input: { minHeight: 48, borderRadius: 12, borderWidth: 1, borderColor: C.line, backgroundColor: '#fff', paddingHorizontal: 14, fontSize: 16, color: C.text },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 16, gap: 10, shadowColor: '#1e2850', shadowOpacity: 0.08, shadowRadius: 14, elevation: 2 },
});
