import * as SecureStore from 'expo-secure-store';
const BASE = process.env.EXPO_PUBLIC_API_URL!;
let access: string | null = null;
export async function setSession(a: string, r: string, user: any) { access = a; await SecureStore.setItemAsync('rt', r); await SecureStore.setItemAsync('u', JSON.stringify(user)); }
export async function loadUser() { const u = await SecureStore.getItemAsync('u'); if (u && (await refresh())) return JSON.parse(u); return null; }
export async function clearSession() { access = null; await SecureStore.deleteItemAsync('rt'); await SecureStore.deleteItemAsync('u'); }
export const token = () => access;
async function refresh() { const rt = await SecureStore.getItemAsync('rt'); if (!rt) return false; const r = await fetch(BASE + '/auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken: rt }) }); if (!r.ok) return false; const j = await r.json(); access = j.accessToken; await SecureStore.setItemAsync('rt', j.refreshToken); return true; }
export async function api<T = any>(path: string, opt: { method?: string; json?: unknown } = {}, retry = true): Promise<T> {
  const r = await fetch(BASE + path, { method: opt.method || 'GET', headers: { 'Content-Type': 'application/json', ...(access ? { Authorization: 'Bearer ' + access } : {}) }, body: opt.json !== undefined ? JSON.stringify(opt.json) : undefined });
  if (r.status === 401 && retry && (await refresh())) return api(path, opt, false);
  const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.message || 'Request failed'); return j;
}
/** Presigned upload: returns fileId to attach to booking/complete. */
export async function upload(uri: string, mime: string, kind: 'problem' | 'after') {
  const { fileId, uploadUrl } = await api('/files/presign', { method: 'POST', json: { kind, mime } });
  const blob = await (await fetch(uri)).blob(); const r = await fetch(uploadUrl, { method: 'PUT', headers: { 'Content-Type': mime }, body: blob });
  if (!r.ok) throw new Error('Upload failed'); return fileId as string;
}
