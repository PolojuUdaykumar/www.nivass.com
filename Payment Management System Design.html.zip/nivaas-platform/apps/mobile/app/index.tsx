import { useEffect, useState } from 'react';
import { Redirect } from 'expo-router';
import { ActivityIndicator, View } from 'react-native';
import { loadUser } from '../src/api';
/** Role-based home: technicians → /tech, customers → /customer, else → /login */
export default function Index() {
  const [u, setU] = useState<any>(undefined);
  useEffect(() => { loadUser().then(setU); }, []);
  if (u === undefined) return <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator /></View>;
  if (!u) return <Redirect href="/login" />;
  return <Redirect href={u.role === 'technician' ? '/tech' : '/customer'} />;
}
