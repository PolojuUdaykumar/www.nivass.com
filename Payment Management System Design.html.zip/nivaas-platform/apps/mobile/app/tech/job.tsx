import { useEffect, useState } from 'react';
import { Alert, Image, ScrollView, Text, View } from 'react-native';
import { Stack, useLocalSearchParams } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import * as ImagePicker from 'expo-image-picker';
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from 'expo-speech-recognition';
import { DEPARTMENTS, RESET_WINDOW_MS, formatINR } from '@nivaas/shared';
import { api, upload } from '../../src/api';
import { Btn, C, Card, Input, Pill } from '../../src/ui';
export default function Job() {
  const { id } = useLocalSearchParams<{ id: string }>(); const qc = useQueryClient();
  const { data: list = [] } = useQuery({ queryKey: ['tjob', id], queryFn: () => api('/bookings?q=' + id) }); const b = list[0];
  const [note, setNote] = useState<string | null>(null); const [mic, setMic] = useState(false); const [after, setAfter] = useState<{ uri: string; id: string }[]>([]);
  const [shiftTo, setShiftTo] = useState(''); const [why, setWhy] = useState(''); const [now, setNow] = useState(Date.now()); const [busy, setBusy] = useState(false);
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);
  useSpeechRecognitionEvent('result', e => { if (e.isFinal) setNote(n => ((n ?? b?.techNote ?? '') + ' ' + e.results[0]?.transcript).trim()); });
  useSpeechRecognitionEvent('end', () => setMic(false));
  if (!b) return null;
  const act = (fn: () => Promise<any>, ok?: string) => async () => { setBusy(true); try { await fn(); if (ok) Alert.alert(ok); qc.invalidateQueries(); } catch (e: any) { Alert.alert('Error', e.message); } finally { setBusy(false); } };
  const resetLeft = b.acceptedAt ? RESET_WINDOW_MS - (now - new Date(b.acceptedAt).getTime()) : 0;
  const canStart = !!b.acceptedAt && !b.startedAt && !b.invoice;
  const pick = async () => { const r = await ImagePicker.launchCameraAsync({ mediaTypes: ['images', 'videos'], quality: 0.7 }); if (r.canceled) return; const a = r.assets[0]; const fid = await upload(a.uri, a.mimeType || 'image/jpeg', 'after'); setAfter(x => [...x, { uri: a.uri, id: fid }]); };
  return (<ScrollView style={{ backgroundColor: C.bg }} contentContainerStyle={{ padding: 14, gap: 12 }}><Stack.Screen options={{ title: b.id }} />
    <Card><Text style={{ fontSize: 20, fontWeight: '800' }}>{b.subService} · {b.customer?.name}</Text><Text style={{ color: C.muted }}>{b.customer?.phone} · {b.preferredSlot}</Text><Text>{b.description || 'No description given.'}</Text></Card>
    {!b.acceptedAt && <Btn title="Accept job" disabled={busy} onPress={act(() => api(`/bookings/${id}/accept`, { method: 'POST' }))} />}
    {(resetLeft > 0 || canStart) && <Card style={{ borderWidth: 1, borderColor: C.accent + '55' }}>
      {resetLeft > 0 && <Text>Accepted by mistake? You can reset for the next {Math.ceil(resetLeft / 1000)} s. Admin will re-assign it.</Text>}
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        {resetLeft > 0 && <Btn kind="secondary" title="Reset work" onPress={act(() => api(`/bookings/${id}/reset`, { method: 'POST', json: { reason: 'Accepted by mistake' } }), 'Job returned to admin')} />}
        {canStart && <Btn title="Start work" disabled={busy} onPress={act(() => api(`/bookings/${id}/start`, { method: 'POST' }))} />}</View></Card>}
    <Card><Text style={{ fontWeight: '700', color: C.accent, fontSize: 12, letterSpacing: 1 }}>TECHNICIAN COMMENT</Text>
      <Input multiline style={{ minHeight: 80, paddingTop: 12 }} placeholder="e.g. Customer not home, will visit at 5 pm." value={note ?? b.techNote ?? ''} onChangeText={setNote} />
      <View style={{ flexDirection: 'row', gap: 8 }}><Btn kind="secondary" title={mic ? 'Stop' : 'Speak'} onPress={async () => { if (mic) return ExpoSpeechRecognitionModule.stop(); const p = await ExpoSpeechRecognitionModule.requestPermissionsAsync(); if (!p.granted) return; setMic(true); ExpoSpeechRecognitionModule.start({ lang: 'hi-IN', interimResults: false, continuous: true }); }} />
        <Btn title="Update comment" disabled={note === null || busy} onPress={act(async () => { await api(`/bookings/${id}/comment`, { method: 'PUT', json: { text: (note || '').trim() } }); setNote(null); }, 'Comment updated')} /></View></Card>
    {b.startedAt && !b.workDoneAt && <Card><Text style={{ fontWeight: '700' }}>Finish work · add at least 2 photos/videos</Text>
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>{after.map(a => <Image key={a.id} source={{ uri: a.uri }} style={{ width: 80, height: 80, borderRadius: 10 }} />)}</View>
      <Btn kind="secondary" title="Take photo / video" onPress={act(pick)} />
      <Btn title="Work completed" disabled={after.length < 2 || busy} onPress={act(() => api(`/bookings/${id}/complete`, { method: 'POST', json: { afterMediaIds: after.map(a => a.id) } }), 'Marked complete')} /></Card>}
    {b.workDoneAt && !b.invoice && <Card><Text style={{ fontWeight: '700' }}>Bill · labour {b.labourPaise != null ? formatINR(b.labourPaise) : 'not set by admin'}</Text>
      <Btn title="Collect UPI (show QR)" onPress={act(() => api(`/bookings/${id}/bill`, { method: 'POST', json: { method: 'upi' } }), 'UPI request created')} />
      <Btn kind="secondary" title="Cash received" onPress={() => Alert.prompt?.('Cash amount (₹)', '', v => act(() => api(`/bookings/${id}/bill`, { method: 'POST', json: { method: 'cash', amountPaise: Math.round(Number(v) * 100) } }), 'Cash recorded · awaiting verification')())} />
      <Btn kind="secondary" title="SEWA (no charge)" onPress={() => Alert.prompt?.('Approver name', 'Staff who approved SEWA', v => act(() => api(`/bookings/${id}/bill`, { method: 'POST', json: { method: 'sewa', approver: v } }), 'SEWA applied')())} /></Card>}
    {!b.invoice && <Card><Text style={{ fontWeight: '700', color: C.accent, fontSize: 12, letterSpacing: 1 }}>SHIFT WORK TO ANOTHER DEPARTMENT</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>{DEPARTMENTS.filter(d => d.id !== b.departmentId).map(d => <Pill key={d.id} label={d.name} color={shiftTo === d.id ? C.accent : C.muted} />)}</View>
      <Input placeholder="Department id (e.g. elec)" value={shiftTo} onChangeText={setShiftTo} autoCapitalize="none" /><Input placeholder="Reason" value={why} onChangeText={setWhy} />
      <Btn kind="secondary" title="Shift work" disabled={!shiftTo || why.length < 5} onPress={act(() => api(`/bookings/${id}/shift`, { method: 'POST', json: { toDepartment: shiftTo, reason: why } }), 'Moved. Admin will assign a new technician.')} /></Card>}
  </ScrollView>);
}
