import { useState } from 'react';
import { FlatList, Pressable, Text, View } from 'react-native';
import { router, Stack } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { api } from '../../src/api';
import { C, Pill } from '../../src/ui';
const kind = (b: any) => b.status === 'cancelled' ? ['Cancelled', C.danger] : b.status === 'closed' ? ['Closed · paid', C.muted] : b.invoice || b.workDoneAt ? ['Work completed', C.done] : b.startedAt ? ['Work started', C.started] : b.acceptedAt ? ['Accepted · not started', C.accepted] : ['New · accept job', C.new];
export default function TechJobs() {
  const [f, setF] = useState<'new' | 'pending' | 'done'>('pending');
  const { data = [], refetch, isFetching } = useQuery({ queryKey: ['tjobs', f], queryFn: () => api('/bookings?filter=' + f), refetchInterval: 20_000 });
  return (<View style={{ flex: 1, backgroundColor: C.bg }}><Stack.Screen options={{ title: 'My works' }} />
    <View style={{ flexDirection: 'row', gap: 8, padding: 12 }}>{([['new', 'New'], ['pending', 'Pending'], ['done', 'Completed']] as const).map(([k, l]) => <Pressable key={k} onPress={() => setF(k)} style={{ paddingHorizontal: 14, minHeight: 40, justifyContent: 'center', borderRadius: 999, backgroundColor: f === k ? C.accent : '#fff' }}><Text style={{ color: f === k ? '#fff' : C.text, fontWeight: '700' }}>{l}</Text></Pressable>)}</View>
    <FlatList data={data} keyExtractor={b => b.id} refreshing={isFetching} onRefresh={refetch} contentContainerStyle={{ padding: 12, gap: 10 }}
      ListEmptyComponent={<Text style={{ color: C.muted, padding: 16 }}>No works here.</Text>}
      renderItem={({ item: b }) => { const [l, c] = kind(b); return (<Pressable onPress={() => router.push({ pathname: '/tech/job', params: { id: b.id } })} style={{ backgroundColor: '#fff', borderRadius: 14, padding: 14, gap: 6, borderLeftWidth: 6, borderLeftColor: c as string }}>
        <Pill label={l as string} color={c as string} /><Text style={{ fontWeight: '700', fontSize: 16 }}>{b.subService} · {b.customer?.name}</Text><Text style={{ color: C.muted }}>{b.id} · {b.preferredSlot}</Text></Pressable>); }} />
  </View>);
}
