import { Stack } from 'expo-router';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
const qc = new QueryClient({ defaultOptions: { queries: { staleTime: 10_000, retry: 1 } } });
export default function Root() { return <QueryClientProvider client={qc}><Stack screenOptions={{ headerShadowVisible: false }} /></QueryClientProvider>; }
