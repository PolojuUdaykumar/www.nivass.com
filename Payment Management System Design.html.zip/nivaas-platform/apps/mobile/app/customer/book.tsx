import { useState } from 'react';
import { Alert, Image, ScrollView, Text, View } from 'react-native';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { DEPARTMENTS } from '@nivaas/shared';
import { api, upload } from '../../src/api';
import { Btn, C, Card, Input } from '../../src/ui';
const SLOTS = ['9 am – 12 pm', '12 – 4 pm', '4 – 8 pm'];
export default function Book() {
  const { dept } = useLocalSearchParams<{ dept: string }>(); const d = DEPARTMENTS.find(x => x.id === dept)!;
  const [sub, setSub] = useState(''); const [type, setType] = useState<'standard' | 'urgent'>('standard'); const [slot, setSlot] = useState(SLOTS[0]); const [desc, setDesc] = useState(''); const [addressId, setAddressId] = useState('');
  const [media, setMedia] = useState<{ uri: string; id: string }[]>([]); const [busy, setBusy] = useState(false);
  const date = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  const add = async () => { const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images', 'videos'], quality: 0.7 }); if (r.canceled) return; const a = r.assets[0]; setMedia(m => [...m, { uri: a.uri, id: '' }]); const id = await upload(a.uri, a.mimeType || 'image/jpeg', 'problem'); setMedia(m => m.map(x => x.uri === a.uri ? { ...x, id } : x)); };
  const submit = async () => { setBusy(true); try { const b = await api('/bookings', { method: 'POST', json: { departmentId: dept, subService: sub, type, date, slot, addressId, description: desc, mediaIds: media.filter(m => m.id).map(m => m.id) } }); Alert.alert('Booked', 'Booking ' + b.id + ' received.'); router.back(); } catch (e: any) { Alert.alert('Error', e.message); } finally { setBusy(false); } };
  return (<ScrollView style={{ backgroundColor: C.bg }} contentContainerStyle={{ padding: 14, gap: 12 }}><Stack.Screen options={{ title: 'Book ' + d.name }} />
    <Card><Input placeholder="What is the problem? (e.g. Tap leaking)" value={sub} onChangeText={setSub} />
      <View style={{ flexDirection: 'row', gap: 8 }}><Btn kind={type === 'standard' ? 'primary' : 'secondary'} title="Standard" onPress={() => setType('standard')} /><Btn kind={type === 'urgent' ? 'primary' : 'secondary'} title="Urgent" onPress={() => setType('urgent')} /></View>
      <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>{SLOTS.map(s => <Btn key={s} kind={slot === s ? 'primary' : 'secondary'} title={s} onPress={() => setSlot(s)} />)}</View>
      <Input placeholder="Saved address ID" value={addressId} onChangeText={setAddressId} />
      <Input multiline style={{ minHeight: 80, paddingTop: 12 }} placeholder="Describe the problem" value={desc} onChangeText={setDesc} />
      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>{media.map(m => <Image key={m.uri} source={{ uri: m.uri }} style={{ width: 72, height: 72, borderRadius: 10, opacity: m.id ? 1 : 0.4 }} />)}</View>
      <Btn kind="secondary" title="Add photo / video" onPress={add} />
      <Btn title="Confirm booking" disabled={!sub || busy} onPress={submit} /><Text style={{ color: C.muted, fontSize: 12 }}>Visit fee is credited to your final bill once the estimate is approved.</Text></Card>
  </ScrollView>);
}
