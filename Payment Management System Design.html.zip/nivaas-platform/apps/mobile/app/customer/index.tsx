import { FlatList, Pressable, Text, View } from 'react-native';
import { router, Stack } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { BOOKING_LABEL, DEPARTMENTS } from '@nivaas/shared';
import { api } from '../../src/api';
import { C, Card, Pill } from '../../src/ui';
export default function CustomerHome() {
  const { data = [] } = useQuery({ queryKey: ['mybookings'], queryFn: () => api('/bookings') });
  return (<View style={{ flex: 1, backgroundColor: C.bg }}><Stack.Screen options={{ title: 'Nivaas' }} />
    <FlatList ListHeaderComponent={<View style={{ gap: 12 }}><Text style={{ fontSize: 22, fontWeight: '800' }}>What needs fixing?</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>{DEPARTMENTS.map(d => <Pressable key={d.id} onPress={() => router.push({ pathname: '/customer/book', params: { dept: d.id } })} style={{ width: '30%', minHeight: 84, backgroundColor: '#fff', borderRadius: 14, alignItems: 'center', justifyContent: 'center', padding: 8 }}><Text style={{ fontWeight: '700', textAlign: 'center' }}>{d.name}</Text></Pressable>)}</View>
      <Text style={{ fontSize: 18, fontWeight: '800', marginTop: 8 }}>My bookings</Text></View>}
      data={data} keyExtractor={b => b.id} contentContainerStyle={{ padding: 14, gap: 10 }}
      renderItem={({ item: b }) => <Card><Pill label={BOOKING_LABEL[b.status as keyof typeof BOOKING_LABEL]} color={C.accent} /><Text style={{ fontWeight: '700' }}>{b.subService}</Text><Text style={{ color: C.muted }}>{b.id} · {b.preferredSlot}</Text></Card>} />
  </View>);
}
