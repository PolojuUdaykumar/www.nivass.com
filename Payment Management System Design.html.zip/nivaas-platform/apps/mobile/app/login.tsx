import { useState } from 'react';
import { router } from 'expo-router';
import { Text, View } from 'react-native';
import { api, setSession } from '../src/api';
import { Btn, C, Card, Input } from '../src/ui';
export default function Login() {
  const [tab, setTab] = useState<'cust' | 'tech'>('cust'); const [phone, setPhone] = useState(''); const [otp, setOtp] = useState(''); const [sent, setSent] = useState(false); const [id, setId] = useState(''); const [pw, setPw] = useState(''); const [err, setErr] = useState('');
  const go = (fn: () => Promise<void>) => async () => { setErr(''); try { await fn(); } catch (e: any) { setErr(e.message); } };
  const done = async (r: any) => { await setSession(r.accessToken, r.refreshToken, r.user); router.replace(r.user.role === 'technician' ? '/tech' : '/customer'); };
  return (<View style={{ flex: 1, padding: 20, justifyContent: 'center', backgroundColor: C.bg }}><Card>
    <Text style={{ fontSize: 26, fontWeight: '800' }}>Nivaas</Text>
    <View style={{ flexDirection: 'row', gap: 8 }}><Btn kind={tab === 'cust' ? 'primary' : 'secondary'} title="Customer" onPress={() => setTab('cust')} /><Btn kind={tab === 'tech' ? 'primary' : 'secondary'} title="Technician" onPress={() => setTab('tech')} /></View>
    {tab === 'cust' ? (!sent ? <><Input keyboardType="number-pad" placeholder="Mobile number" value={phone} onChangeText={setPhone} maxLength={10} /><Btn title="Send OTP" onPress={go(async () => { await api('/auth/otp/send', { method: 'POST', json: { phone } }); setSent(true); })} /></>
      : <><Input keyboardType="number-pad" placeholder="6-digit OTP" value={otp} onChangeText={setOtp} maxLength={6} /><Btn title="Verify & continue" onPress={go(async () => done(await api('/auth/otp/verify', { method: 'POST', json: { phone, otp } })))} /></>)
      : <><Input autoCapitalize="none" placeholder="Login ID" value={id} onChangeText={setId} /><Input secureTextEntry placeholder="Password" value={pw} onChangeText={setPw} /><Btn title="Sign in" onPress={go(async () => done(await api('/auth/login', { method: 'POST', json: { login: id, password: pw } })))} /></>}
    {!!err && <Text style={{ color: C.danger }}>{err}</Text>}
  </Card></View>);
}
