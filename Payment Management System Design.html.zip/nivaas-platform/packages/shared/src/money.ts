/** All money is integer paise. */
export const rupeesToPaise = (v: string | number) => { const n = parseFloat(String(v).replace(/[₹,\s]/g, '')); return Number.isFinite(n) ? Math.round(n * 100) : NaN; };
export const formatINR = (p: number) => '₹' + (p / 100).toLocaleString('en-IN', { minimumFractionDigits: p % 100 ? 2 : 0, maximumFractionDigits: 2 });
