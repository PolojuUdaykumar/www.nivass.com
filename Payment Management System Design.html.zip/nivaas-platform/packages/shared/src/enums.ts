export const ROLES = ['customer', 'technician', 'super_admin', 'admin', 'ops_admin', 'support', 'finance'] as const;
export type Role = (typeof ROLES)[number];
export const ADMIN_ROLES: Role[] = ['super_admin', 'admin', 'ops_admin'];
export const DEPT_SCOPED: Role[] = ['admin', 'ops_admin'];

export const BOOKING_STATUS = ['booking_received', 'technician_assigned', 'awaiting_confirmation', 'site_visit_scheduled', 'estimate_pending', 'estimate_approved', 'work_in_progress', 'payment_pending', 'closed', 'cancelled'] as const;
export type BookingStatus = (typeof BOOKING_STATUS)[number];
export const BOOKING_LABEL: Record<BookingStatus, string> = {
  booking_received: 'Booking received', technician_assigned: 'Technician assigned', awaiting_confirmation: 'Awaiting confirmation',
  site_visit_scheduled: 'Site visit scheduled', estimate_pending: 'Estimate pending approval', estimate_approved: 'Estimate approved',
  work_in_progress: 'Work in progress', payment_pending: 'Payment pending', closed: 'Closed', cancelled: 'Cancelled',
};
export const PAY_STATUS = ['pending', 'awaiting_verification', 'partially_paid', 'paid', 'failed', 'cancelled', 'refund_pending', 'partially_refunded', 'refunded', 'sewa_no_charge'] as const;
export type PayStatus = (typeof PAY_STATUS)[number];
export const VERIFIED: PayStatus[] = ['paid', 'partially_paid', 'refund_pending', 'partially_refunded', 'refunded', 'sewa_no_charge'];

export const DEPARTMENTS = [
  { id: 'plumb', name: 'Plumber', code: 'P' }, { id: 'elec', name: 'Electrical', code: 'E' }, { id: 'ac', name: 'AC work', code: 'A' },
  { id: 'carp', name: 'Carpenter', code: 'C', inspection: true }, { id: 'paint', name: 'Painting', code: 'PT' }, { id: 'ro', name: 'RO Purifier', code: 'R' },
  { id: 'weld', name: 'Welding', code: 'W' }, { id: 'inspect', name: 'General Inspection', code: 'I' }, { id: 'mason', name: 'Cement work', code: 'CM', inspection: true },
] as const;

export const RESET_WINDOW_MS = 2 * 60 * 1000;
export const MIN_AFTER_MEDIA = 2;
