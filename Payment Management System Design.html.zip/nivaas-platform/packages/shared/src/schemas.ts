import { z } from 'zod';
export const phone = z.string().regex(/^[6-9]\d{9}$/, 'Enter a valid 10-digit mobile number');
export const CreateBooking = z.object({
  departmentId: z.string(), subService: z.string().min(1), type: z.enum(['standard', 'urgent']),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), slot: z.string(), addressId: z.string().uuid(),
  description: z.string().max(2000).optional(), mediaIds: z.array(z.string().uuid()).max(10).default([]),
});
export const Comment = z.object({ text: z.string().max(1000) });
export const Shift = z.object({ toDepartment: z.string(), reason: z.string().min(5, 'Give a reason (min 5 characters)') });
export const Labour = z.object({ paise: z.number().int().min(0) });
export const Assign = z.object({ technicianId: z.string().uuid() });
export const Complete = z.object({ afterMediaIds: z.array(z.string().uuid()).min(2, 'Add at least 2 photos or videos of the finished work') });
export const Bill = z.discriminatedUnion('method', [
  z.object({ method: z.literal('upi'), utr: z.string().min(6).optional() }),
  z.object({ method: z.literal('cash'), amountPaise: z.number().int().positive() }),
  z.object({ method: z.literal('sewa'), approver: z.string().min(3) }),
]);
export const CashHandover = z.object({ to: z.string().min(2), amountPaise: z.number().int().positive(), note: z.string().optional() });
export const StockImportRow = z.object({
  name: z.string().min(1), partNo: z.string().optional().default(''), brand: z.string().optional().default(''),
  department: z.string().min(1), unit: z.string().default('pcs'), cost: z.number().nonnegative().optional(),
  price: z.number().nonnegative().optional(), qty: z.number().nonnegative(), min: z.number().int().nonnegative().optional(),
  supplier: z.string().optional(), location: z.string().optional(),
});
export type CreateBookingDto = z.infer<typeof CreateBooking>;
