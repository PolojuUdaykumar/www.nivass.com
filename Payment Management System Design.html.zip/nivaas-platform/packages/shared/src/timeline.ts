/** Work-to-work timeline. Gaps only counted within the same calendar day (IST). */
export type JobSpan = { id: string; label: string; assignedAt: number; acceptedAt: number; startedAt: number; doneAt?: number };
export type TLItem =
  | { kind: 'point'; at: number; title: 'Work assigned' | 'Accepted' | 'Work started' | 'Work completed'; jobId: string; label: string }
  | { kind: 'gap'; from: number; to: number; mins: number; type: 'working' | 'idle_before_start' | 'took_to_accept' | 'idle_no_work'; live?: boolean }
  | { kind: 'day'; at: number };
const day = (t: number) => new Date(t + 5.5 * 36e5).toISOString().slice(0, 10);
export function buildTimeline(jobs: JobSpan[], now = Date.now(), live = true) {
  const P: { at: number; k: 'assign' | 'accept' | 'start' | 'done'; id: string; label: string }[] = [];
  for (const j of jobs) {
    P.push({ at: j.assignedAt, k: 'assign', id: j.id, label: j.label }, { at: j.acceptedAt, k: 'accept', id: j.id, label: j.label }, { at: j.startedAt, k: 'start', id: j.id, label: j.label });
    if (j.doneAt) P.push({ at: j.doneAt, k: 'done', id: j.id, label: j.label });
  }
  const ord = { done: 0, assign: 1, accept: 2, start: 3 } as const;
  P.sort((a, b) => a.at - b.at || ord[a.k] - ord[b.k]);
  const title = { assign: 'Work assigned', accept: 'Accepted', start: 'Work started', done: 'Work completed' } as const;
  const state = new Map<string, 'assign' | 'accept' | 'start'>();
  const out: TLItem[] = []; const tot = { working: 0, idle_before_start: 0, took_to_accept: 0, idle_no_work: 0 };
  const fill = (from: number, to: number, isLive = false) => {
    const mins = Math.round((to - from) / 6e4); if (mins <= 0) return;
    const v = [...state.values()];
    const type = v.includes('start') ? 'working' : v.includes('accept') ? 'idle_before_start' : v.includes('assign') ? 'took_to_accept' : 'idle_no_work';
    tot[type] += mins; out.push({ kind: 'gap', from, to, mins, type, live: isLive });
  };
  let last: number | null = null;
  for (const p of P) {
    if (last === null || day(last) !== day(p.at)) out.push({ kind: 'day', at: p.at }); else fill(last, p.at);
    out.push({ kind: 'point', at: p.at, title: title[p.k], jobId: p.id, label: p.label });
    if (p.k === 'done') state.delete(p.id); else state.set(p.id, p.k);
    last = p.at;
  }
  if (live && last !== null && day(last) === day(now)) fill(last, now, true);
  return { items: out, totals: tot, jobs: jobs.length };
}
export function periodRange(period: 'today' | 'yesterday' | 'week' | 'month', now = new Date()) {
  const d0 = new Date(now); d0.setHours(0, 0, 0, 0); const DAY = 864e5;
  if (period === 'today') return [d0.getTime(), Infinity];
  if (period === 'yesterday') return [d0.getTime() - DAY, d0.getTime()];
  if (period === 'week') return [d0.getTime() - ((d0.getDay() + 6) % 7) * DAY, Infinity];
  return [new Date(d0.getFullYear(), d0.getMonth(), 1).getTime(), Infinity];
}
