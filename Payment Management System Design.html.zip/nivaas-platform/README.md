# Nivaas Platform — source code

Monorepo for the Nivaas home-services platform: **API (NestJS + PostgreSQL)**, **website + admin console (Next.js)**, **mobile app for customers and technicians (Expo / React Native)**, and a **shared** package for types, validation and business rules.

```
apps/api       NestJS · Prisma · Socket.IO · Razorpay · S3 uploads · SheetJS
apps/web       Next.js 15 · Tailwind · TanStack Query   (/  /book  /login  /admin/*)
apps/mobile    Expo Router · SecureStore · Camera · Speech-to-text
packages/shared  enums, zod schemas, money (paise), timeline builder
```

## Run locally
```bash
corepack enable && pnpm install
cp .env.example apps/api/.env          # fill secrets
cp .env.example apps/web/.env.local
cp .env.example apps/mobile/.env
docker compose up -d                   # Postgres, Redis, MinIO (create bucket "nivaas" at :9001)
pnpm --filter @nivaas/shared build
pnpm --filter api exec prisma migrate dev --name init
pnpm db:seed                           # admin: anita@nivaas.in / ChangeMe@123 · tech: ravi.k / ChangeMe@123
pnpm dev                               # api :4000 · web :3000 · expo QR
```

## What is implemented
| Area | API | Web | Mobile |
|---|---|---|---|
| Auth: customer OTP, staff password, JWT + rotating refresh, sessions | ✔ | ✔ | ✔ |
| RBAC + department scoping (server-enforced) | ✔ | ✔ | — |
| Booking create (fees from settings, human IDs) | ✔ | ✔ | ✔ (photos/videos) |
| Assign, labour, accept, **2-min reset**, start, complete (≥2 photos), comment, shift, cancel | ✔ | queue | technician job screen |
| Technician updates feed, comment edit by admin | ✔ | ✔ | — |
| Bill (UPI gateway / cash / SEWA), verify, refund, auto-close, Razorpay webhook | ✔ | payments | ✔ |
| Cash in hand + handover | ✔ | — | API ready |
| Inventory + **Excel import (preview → commit, add/set)** + template | ✔ | ✔ | — |
| Time track: work-to-work timeline (Today/Yesterday/Week/Month) + Excel | ✔ | ✔ | — |
| Audit: admin changes (before/after), login/logout sessions, all activity | ✔ | ✔ | — |
| Live updates (Socket.IO rooms per dept/user/booking) | ✔ | ✔ | polling |

## Next steps (in order)
1. Wire SMS/WhatsApp provider in `auth.service.ts` (OTP) and a BullMQ worker for completion messages.
2. Move OTP store to Redis; add rate limits per phone.
3. Remaining admin screens from the prototype: Overview, Material & purchase requests, Technicians/Admin team CRUD, Services, Pricing (APIs exist for most).
4. Customer addresses CRUD + map pin; estimate approval screen.
5. Push notifications (expo-notifications) on `booking.assigned` for technicians.
6. Tests: unit (status rules, timeline), e2e (Supertest) for booking → bill → verify → closed.
7. Deploy: API + Postgres (RDS/Railway), web on Vercel, mobile via EAS Build → Play Store.

## Business rules
See `packages/shared` and the handoff README (`design_handoff_nivaas_platform/README.md`). Money is always integer **paise**.
